<?php
session_start();
// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SportsHub</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <h2>SportsHub Admin</h2>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li class="active">
                        <a href="dashboard.php">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="events.php">
                            <i class="fas fa-calendar-alt"></i>
                            <span>Events</span>
                        </a>
                    </li>
                    <li>
                        <a href="manage-news.php">
                            <i class="fas fa-newspaper"></i>
                            <span>News</span>
                        </a>
                    </li>
                    <li>
                        <a href="users.php">
                            <i class="fas fa-users"></i>
                            <span>Users</span>
                        </a>
                    </li>
                    <li>
                        <a href="logout.php">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <main class="admin-main">
            <header class="admin-header">
                <div class="header-search">
                    <input type="text" placeholder="Search...">
                    <button><i class="fas fa-search"></i></button>
                </div>
                <div class="header-user">
                    <span>Welcome, <?php echo $_SESSION['username']; ?></span>
                    <img src="https://via.placeholder.com/40" alt="Admin" class="user-avatar">
                </div>
            </header>

            <div class="admin-content">
                <h1>Dashboard</h1>
                
                <div class="dashboard-stats">
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-calendar-alt"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Total Events</h3>
                            <p>24</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-newspaper"></i>
                        </div>
                        <div class="stat-info">
                            <h3>News Articles</h3>
                            <p>156</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Registered Users</h3>
                            <p>1,248</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-ticket-alt"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Event Registrations</h3>
                            <p>3,567</p>
                        </div>
                    </div>
                </div>

                <div class="dashboard-recent">
                    <div class="recent-events">
                        <h2>Recent Events</h2>
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Event Name</th>
                                    <th>Date</th>
                                    <th>Location</th>
                                    <th>Registrations</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>City Marathon 2024</td>
                                    <td>March 15, 2024</td>
                                    <td>Central Park</td>
                                    <td>245</td>
                                    <td>
                                        <button class="btn-icon"><i class="fas fa-edit"></i></button>
                                        <button class="btn-icon"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>National Swimming Championship</td>
                                    <td>April 5, 2024</td>
                                    <td>Olympic Pool</td>
                                    <td>189</td>
                                    <td>
                                        <button class="btn-icon"><i class="fas fa-edit"></i></button>
                                        <button class="btn-icon"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>International Cricket Series</td>
                                    <td>May 10, 2024</td>
                                    <td>Cricket Stadium</td>
                                    <td>312</td>
                                    <td>
                                        <button class="btn-icon"><i class="fas fa-edit"></i></button>
                                        <button class="btn-icon"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="recent-news">
                        <h2>Recent News</h2>
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Category</th>
                                    <th>Date</th>
                                    <th>Views</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Championship Finals Highlights</td>
                                    <td>Football</td>
                                    <td>Apr 12, 2024</td>
                                    <td>1,245</td>
                                    <td>
                                        <button class="btn-icon"><i class="fas fa-edit"></i></button>
                                        <button class="btn-icon"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>NBA Playoffs Update</td>
                                    <td>Basketball</td>
                                    <td>Apr 10, 2024</td>
                                    <td>987</td>
                                    <td>
                                        <button class="btn-icon"><i class="fas fa-edit"></i></button>
                                        <button class="btn-icon"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Grand Slam Tournament Results</td>
                                    <td>Tennis</td>
                                    <td>Apr 8, 2024</td>
                                    <td>756</td>
                                    <td>
                                        <button class="btn-icon"><i class="fas fa-edit"></i></button>
                                        <button class="btn-icon"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html> 
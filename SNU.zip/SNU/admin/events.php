<?php
session_start();
// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Events - SportsHub Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <h2>SportsHub Admin</h2>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="dashboard.php">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="active">
                        <a href="events.php">
                            <i class="fas fa-calendar-alt"></i>
                            <span>Events</span>
                        </a>
                    </li>
                    <li>
                        <a href="manage-news.php">
                            <i class="fas fa-newspaper"></i>
                            <span>News</span>
                        </a>
                    </li>
                    <li>
                        <a href="users.php">
                            <i class="fas fa-users"></i>
                            <span>Users</span>
                        </a>
                    </li>
                    <li>
                        <a href="logout.php">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <main class="admin-main">
            <header class="admin-header">
                <div class="header-search">
                    <input type="text" placeholder="Search events...">
                    <button><i class="fas fa-search"></i></button>
                </div>
                <div class="header-user">
                    <span>Welcome, <?php echo $_SESSION['username']; ?></span>
                    <img src="https://via.placeholder.com/40" alt="Admin" class="user-avatar">
                </div>
            </header>

            <div class="admin-content">
                <div class="content-header">
                    <h1>Manage Events</h1>
                    <button class="btn btn-primary" id="addEventBtn">
                        <i class="fas fa-plus"></i> Add New Event
                    </button>
                </div>

                <div class="content-filters">
                    <div class="filter-group">
                        <label for="categoryFilter">Category:</label>
                        <select id="categoryFilter">
                            <option value="all">All Categories</option>
                            <option value="football">Football</option>
                            <option value="basketball">Basketball</option>
                            <option value="tennis">Tennis</option>
                            <option value="cricket">Cricket</option>
                            <option value="marathon">Marathon</option>
                            <option value="swimming">Swimming</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="statusFilter">Status:</label>
                        <select id="statusFilter">
                            <option value="all">All Status</option>
                            <option value="upcoming">Upcoming</option>
                            <option value="ongoing">Ongoing</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="dateFilter">Date:</label>
                        <input type="date" id="dateFilter">
                    </div>
                </div>

                <div class="events-table-container">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Event Name</th>
                                <th>Category</th>
                                <th>Date</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Registrations</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>City Marathon 2024</td>
                                <td>Marathon</td>
                                <td>March 15, 2024</td>
                                <td>Central Park</td>
                                <td><span class="status-badge upcoming">Upcoming</span></td>
                                <td>245</td>
                                <td>
                                    <button class="btn-icon" title="View Details"><i class="fas fa-eye"></i></button>
                                    <button class="btn-icon" title="Edit Event"><i class="fas fa-edit"></i></button>
                                    <button class="btn-icon" title="Delete Event"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>National Swimming Championship</td>
                                <td>Swimming</td>
                                <td>April 5, 2024</td>
                                <td>Olympic Pool</td>
                                <td><span class="status-badge upcoming">Upcoming</span></td>
                                <td>189</td>
                                <td>
                                    <button class="btn-icon" title="View Details"><i class="fas fa-eye"></i></button>
                                    <button class="btn-icon" title="Edit Event"><i class="fas fa-edit"></i></button>
                                    <button class="btn-icon" title="Delete Event"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>International Cricket Series</td>
                                <td>Cricket</td>
                                <td>May 10, 2024</td>
                                <td>Cricket Stadium</td>
                                <td><span class="status-badge upcoming">Upcoming</span></td>
                                <td>312</td>
                                <td>
                                    <button class="btn-icon" title="View Details"><i class="fas fa-eye"></i></button>
                                    <button class="btn-icon" title="Edit Event"><i class="fas fa-edit"></i></button>
                                    <button class="btn-icon" title="Delete Event"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>3x3 Street Basketball Tournament</td>
                                <td>Basketball</td>
                                <td>May 25, 2024</td>
                                <td>Downtown Courts</td>
                                <td><span class="status-badge upcoming">Upcoming</span></td>
                                <td>178</td>
                                <td>
                                    <button class="btn-icon" title="View Details"><i class="fas fa-eye"></i></button>
                                    <button class="btn-icon" title="Edit Event"><i class="fas fa-edit"></i></button>
                                    <button class="btn-icon" title="Delete Event"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>Junior Tennis Championship</td>
                                <td>Tennis</td>
                                <td>June 5-7, 2024</td>
                                <td>City Tennis Club</td>
                                <td><span class="status-badge upcoming">Upcoming</span></td>
                                <td>156</td>
                                <td>
                                    <button class="btn-icon" title="View Details"><i class="fas fa-eye"></i></button>
                                    <button class="btn-icon" title="Edit Event"><i class="fas fa-edit"></i></button>
                                    <button class="btn-icon" title="Delete Event"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>T20 Cricket League</td>
                                <td>Cricket</td>
                                <td>June 20-25, 2024</td>
                                <td>City Cricket Ground</td>
                                <td><span class="status-badge upcoming">Upcoming</span></td>
                                <td>289</td>
                                <td>
                                    <button class="btn-icon" title="View Details"><i class="fas fa-eye"></i></button>
                                    <button class="btn-icon" title="Edit Event"><i class="fas fa-edit"></i></button>
                                    <button class="btn-icon" title="Delete Event"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>Youth Football Camp</td>
                                <td>Football</td>
                                <td>July 1-15, 2024</td>
                                <td>Sports Academy</td>
                                <td><span class="status-badge upcoming">Upcoming</span></td>
                                <td>124</td>
                                <td>
                                    <button class="btn-icon" title="View Details"><i class="fas fa-eye"></i></button>
                                    <button class="btn-icon" title="Edit Event"><i class="fas fa-edit"></i></button>
                                    <button class="btn-icon" title="Delete Event"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="pagination">
                    <button class="pagination-btn"><i class="fas fa-chevron-left"></i></button>
                    <button class="pagination-btn active">1</button>
                    <button class="pagination-btn">2</button>
                    <button class="pagination-btn">3</button>
                    <button class="pagination-btn"><i class="fas fa-chevron-right"></i></button>
                </div>
            </div>
        </main>
    </div>

    <!-- Add/Edit Event Modal -->
    <div class="modal" id="eventModal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <h2 id="modalTitle">Add New Event</h2>
            <form id="eventForm">
                <div class="form-group">
                    <label for="eventName">Event Name</label>
                    <input type="text" id="eventName" name="eventName" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="eventCategory">Category</label>
                        <select id="eventCategory" name="eventCategory" required>
                            <option value="">Select Category</option>
                            <option value="football">Football</option>
                            <option value="basketball">Basketball</option>
                            <option value="tennis">Tennis</option>
                            <option value="cricket">Cricket</option>
                            <option value="marathon">Marathon</option>
                            <option value="swimming">Swimming</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="eventStatus">Status</label>
                        <select id="eventStatus" name="eventStatus" required>
                            <option value="">Select Status</option>
                            <option value="upcoming">Upcoming</option>
                            <option value="ongoing">Ongoing</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="eventDate">Date</label>
                        <input type="date" id="eventDate" name="eventDate" required>
                    </div>
                    <div class="form-group">
                        <label for="eventTime">Time</label>
                        <input type="time" id="eventTime" name="eventTime" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="eventLocation">Location</label>
                    <input type="text" id="eventLocation" name="eventLocation" required>
                </div>
                <div class="form-group">
                    <label for="eventDescription">Description</label>
                    <textarea id="eventDescription" name="eventDescription" rows="4" required></textarea>
                </div>
                <div class="form-group">
                    <label for="eventImage">Event Image</label>
                    <input type="file" id="eventImage" name="eventImage" accept="image/*">
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" id="cancelBtn">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Event</button>
                </div>
            </form>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
    <script>
        // Event modal functionality
        const modal = document.getElementById('eventModal');
        const addEventBtn = document.getElementById('addEventBtn');
        const closeModal = document.querySelector('.close-modal');
        const cancelBtn = document.getElementById('cancelBtn');
        const eventForm = document.getElementById('eventForm');
        
        // Open modal
        addEventBtn.addEventListener('click', () => {
            modal.style.display = 'block';
            document.getElementById('modalTitle').textContent = 'Add New Event';
            eventForm.reset();
        });
        
        // Close modal
        closeModal.addEventListener('click', () => {
            modal.style.display = 'none';
        });
        
        cancelBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });
        
        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
        
        // Form submission
        eventForm.addEventListener('submit', (e) => {
            e.preventDefault();
            // Here you would typically send the form data to the server
            console.log('Event form submitted');
            modal.style.display = 'none';
            // Show success message
            alert('Event saved successfully!');
        });
        
        // Edit button functionality
        const editButtons = document.querySelectorAll('.btn-icon[title="Edit Event"]');
        editButtons.forEach(button => {
            button.addEventListener('click', () => {
                const row = button.closest('tr');
                const eventName = row.querySelector('td:first-child').textContent;
                const eventCategory = row.querySelector('td:nth-child(2)').textContent;
                const eventDate = row.querySelector('td:nth-child(3)').textContent;
                const eventLocation = row.querySelector('td:nth-child(4)').textContent;
                const eventStatus = row.querySelector('.status-badge').textContent;
                
                // Populate form with event data
                document.getElementById('modalTitle').textContent = 'Edit Event';
                document.getElementById('eventName').value = eventName;
                document.getElementById('eventCategory').value = eventCategory.toLowerCase();
                document.getElementById('eventStatus').value = eventStatus.toLowerCase();
                document.getElementById('eventDate').value = formatDateForInput(eventDate);
                document.getElementById('eventLocation').value = eventLocation;
                
                // Show modal
                modal.style.display = 'block';
            });
        });
        
        // Helper function to format date for input
        function formatDateForInput(dateString) {
            const months = {
                'January': '01', 'February': '02', 'March': '03', 'April': '04',
                'May': '05', 'June': '06', 'July': '07', 'August': '08',
                'September': '09', 'October': '10', 'November': '11', 'December': '12'
            };
            
            const parts = dateString.split(' ');
            if (parts.length === 3) {
                const month = months[parts[0]];
                const day = parts[1].replace(',', '');
                const year = parts[2];
                return `${year}-${month}-${day.padStart(2, '0')}`;
            }
            
            return '';
        }
    </script>
</body>
</html> 
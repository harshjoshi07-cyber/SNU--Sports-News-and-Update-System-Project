<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === 'harsh' && $password === 'harsh') {
        $_SESSION['admin_id'] = 1;
        $_SESSION['admin_username'] = 'harsh';
        header("Location: /admin/index.php");
        exit();
    } else {
        $error = "Invalid username or password";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - SportsHub</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/auth.css">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="admin-login-container">
        <div class="admin-login-card">
            <div class="admin-login-header">
                <h2>Admin Portal</h2>
                <p>Access the SportsHub admin dashboard</p>
            </div>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="auth-form" novalidate>
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user-shield"></i>
                        Admin Username
                    </label>
                    <input type="text" id="username" name="username" required 
                           placeholder="Enter admin username">
                    <div class="invalid-feedback">Please enter your username</div>
                </div>
                
                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i>
                        Password
                    </label>
                    <input type="password" id="password" name="password" required 
                           placeholder="Enter admin password">
                    <div class="invalid-feedback">Please enter your password</div>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-block">
                        <i class="fas fa-sign-in-alt"></i>
                        Login
                    </button>
                </div>

                <div class="form-links">
                    <a href="../index.php">
                        <i class="fas fa-home"></i>
                        Back to Home
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script src="../assets/js/main.js"></script>
</body>
</html> 
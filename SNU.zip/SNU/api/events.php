<?php
require_once '../includes/config.php';
header('Content-Type: application/json');

// Get query parameters
$category = isset($_GET['category']) ? sanitizeInput($_GET['category']) : null;
$status = isset($_GET['status']) ? sanitizeInput($_GET['status']) : 'upcoming';
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;

try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }

    $query = "SELECT e.*, u.username as organizer_name, c.name as category_name,
              COUNT(er.id) as registered_participants
              FROM events e 
              LEFT JOIN users u ON e.organizer_id = u.id 
              LEFT JOIN sports_categories c ON e.category_id = c.id
              LEFT JOIN event_registrations er ON e.id = er.event_id AND er.payment_status = 'completed'
              WHERE e.status = ?";

    $params = [$status];

    if ($category) {
        $query .= " AND c.name = ?";
        $params[] = $category;
    }

    $query .= " GROUP BY e.id ORDER BY e.start_date ASC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;

    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $events = $stmt->fetchAll();

    // Format the response
    $response = array_map(function($event) {
        return [
            'id' => $event['id'],
            'title' => $event['title'],
            'description' => $event['description'],
            'start_date' => $event['start_date'],
            'end_date' => $event['end_date'],
            'location' => $event['location'],
            'organizer' => $event['organizer_name'],
            'category' => $event['category_name'],
            'max_participants' => $event['max_participants'],
            'registered_participants' => $event['registered_participants'],
            'registration_fee' => $event['registration_fee'],
            'image' => $event['image'],
            'status' => $event['status']
        ];
    }, $events);

    sendJSONResponse($response);

} catch (Exception $e) {
    error_log("Events API error: " . $e->getMessage());
    sendJSONResponse(['error' => 'An error occurred while fetching events'], 500);
}
?> 
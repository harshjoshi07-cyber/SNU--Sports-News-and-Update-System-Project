<?php
require_once '../includes/config.php';
header('Content-Type: application/json');

// Check if user is logged in
session_start();
if (!isLoggedIn()) {
    sendJSONResponse(['error' => 'Authentication required'], 401);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSONResponse(['error' => 'Method not allowed'], 405);
    exit();
}

try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }

    // Get and validate input
    $event_id = isset($_POST['event_id']) ? (int)$_POST['event_id'] : 0;
    $user_id = $_SESSION['user_id'];
    $csrf_token = $_POST['csrf_token'] ?? '';

    if (!verifyCSRFToken($csrf_token)) {
        sendJSONResponse(['error' => 'Invalid request'], 400);
        exit();
    }

    // Start transaction
    $conn->beginTransaction();

    try {
        // Check if event exists and get details
        $stmt = $conn->prepare("SELECT * FROM events WHERE id = ? AND status = 'upcoming'");
        $stmt->execute([$event_id]);
        $event = $stmt->fetch();

        if (!$event) {
            throw new Exception('Event not found or registration closed');
        }

        // Check if user is already registered
        $stmt = $conn->prepare("SELECT id FROM event_registrations WHERE event_id = ? AND user_id = ?");
        $stmt->execute([$event_id, $user_id]);
        if ($stmt->fetch()) {
            throw new Exception('You are already registered for this event');
        }

        // Check if event has available spots
        $stmt = $conn->prepare("SELECT COUNT(*) FROM event_registrations WHERE event_id = ? AND payment_status = 'completed'");
        $stmt->execute([$event_id]);
        $registered_count = $stmt->fetchColumn();

        if ($event['max_participants'] > 0 && $registered_count >= $event['max_participants']) {
            throw new Exception('Event is full');
        }

        // Create registration record
        $stmt = $conn->prepare("INSERT INTO event_registrations (event_id, user_id, payment_status, payment_amount) VALUES (?, ?, 'pending', ?)");
        $stmt->execute([$event_id, $user_id, $event['registration_fee']]);
        $registration_id = $conn->lastInsertId();

        // If event is free, mark as completed
        if ($event['registration_fee'] == 0) {
            $stmt = $conn->prepare("UPDATE event_registrations SET payment_status = 'completed', payment_date = NOW() WHERE id = ?");
            $stmt->execute([$registration_id]);
        }

        // Commit transaction
        $conn->commit();

        // Return success response
        $response = [
            'success' => true,
            'message' => 'Registration successful',
            'registration_id' => $registration_id,
            'payment_required' => $event['registration_fee'] > 0
        ];

        if ($event['registration_fee'] > 0) {
            // Here you would integrate with a payment gateway
            // For now, we'll just return the amount
            $response['amount'] = $event['registration_fee'];
        }

        sendJSONResponse($response);

    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollBack();
        throw $e;
    }

} catch (Exception $e) {
    error_log("Event registration error: " . $e->getMessage());
    sendJSONResponse(['error' => $e->getMessage()], 400);
}
?> 
 
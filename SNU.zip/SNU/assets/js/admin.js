document.addEventListener('DOMContentLoaded', function() {
    // Initialize admin functionality
    initAdmin();
});

function initAdmin() {
    // Initialize modals
    initModals();
    
    // Initialize filters
    initFilters();
    
    // Initialize search
    initSearch();
    
    // Initialize tables
    initTables();
}

// Modal functionality
function initModals() {
    const modals = document.querySelectorAll('.modal');
    const closeButtons = document.querySelectorAll('.close-modal');
    
    // Close modal when clicking outside
    modals.forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal(modal);
            }
        });
    });
    
    // Close modal when clicking close button
    closeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const modal = button.closest('.modal');
            closeModal(modal);
        });
    });
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modal) {
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Filter functionality
function initFilters() {
    const filterGroups = document.querySelectorAll('.filter-group');
    
    filterGroups.forEach(group => {
        const select = group.querySelector('select');
        const input = group.querySelector('input');
        
        if (select) {
            select.addEventListener('change', function() {
                applyFilters();
            });
        }
        
        if (input) {
            input.addEventListener('change', function() {
                applyFilters();
            });
        }
    });
}

function applyFilters() {
    const categoryFilter = document.querySelector('select[name="category"]')?.value;
    const statusFilter = document.querySelector('select[name="status"]')?.value;
    const dateFilter = document.querySelector('input[name="date"]')?.value;
    
    const rows = document.querySelectorAll('.admin-table tbody tr');
    
    rows.forEach(row => {
        const category = row.getAttribute('data-category');
        const status = row.getAttribute('data-status');
        const date = row.getAttribute('data-date');
        
        let showRow = true;
        
        if (categoryFilter && categoryFilter !== 'all' && category !== categoryFilter) {
            showRow = false;
        }
        
        if (statusFilter && statusFilter !== 'all' && status !== statusFilter) {
            showRow = false;
        }
        
        if (dateFilter && date !== dateFilter) {
            showRow = false;
        }
        
        row.style.display = showRow ? '' : 'none';
    });
}

// Search functionality
function initSearch() {
    const searchInput = document.querySelector('.header-search input');
    
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('.admin-table tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
}

// Table functionality
function initTables() {
    const tables = document.querySelectorAll('.admin-table');
    
    tables.forEach(table => {
        const headers = table.querySelectorAll('th');
        
        headers.forEach(header => {
            if (header.classList.contains('sortable')) {
                header.addEventListener('click', function() {
                    const column = this.getAttribute('data-column');
                    const direction = this.getAttribute('data-direction') === 'asc' ? 'desc' : 'asc';
                    
                    // Update sort direction
                    headers.forEach(h => h.setAttribute('data-direction', ''));
                    this.setAttribute('data-direction', direction);
                    
                    // Sort table
                    sortTable(table, column, direction);
                });
            }
        });
    });
}

function sortTable(table, column, direction) {
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    
    rows.sort((a, b) => {
        const aValue = a.querySelector(`td[data-column="${column}"]`).textContent;
        const bValue = b.querySelector(`td[data-column="${column}"]`).textContent;
        
        if (direction === 'asc') {
            return aValue.localeCompare(bValue);
        } else {
            return bValue.localeCompare(aValue);
        }
    });
    
    // Clear table
    while (tbody.firstChild) {
        tbody.removeChild(tbody.firstChild);
    }
    
    // Add sorted rows
    rows.forEach(row => tbody.appendChild(row));
}

// Event form handling
function handleEventForm(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    
    // Validate form
    if (!validateEventForm(formData)) {
        return;
    }
    
    // Submit form
    submitEventForm(formData);
}

function validateEventForm(formData) {
    const name = formData.get('name');
    const category = formData.get('category');
    const date = formData.get('date');
    const time = formData.get('time');
    const location = formData.get('location');
    
    if (!name || !category || !date || !time || !location) {
        showError('Please fill in all required fields');
        return false;
    }
    
    return true;
}

function submitEventForm(formData) {
    // Show loading state
    const submitButton = document.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.textContent = 'Saving...';
    submitButton.disabled = true;
    
    // Submit form data
    fetch('admin/events.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccess('Event saved successfully');
            closeModal(document.querySelector('.modal'));
            // Refresh table or update UI
            location.reload();
        } else {
            showError(data.message || 'Error saving event');
        }
    })
    .catch(error => {
        showError('Error saving event');
        console.error('Error:', error);
    })
    .finally(() => {
        // Reset button state
        submitButton.textContent = originalText;
        submitButton.disabled = false;
    });
}

// Notification functions
function showSuccess(message) {
    showNotification(message, 'success');
}

function showError(message) {
    showNotification(message, 'error');
}

function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Delete confirmation
function confirmDelete(eventId) {
    if (confirm('Are you sure you want to delete this event? This action cannot be undone.')) {
        deleteEvent(eventId);
    }
}

function deleteEvent(eventId) {
    fetch(`admin/events.php?id=${eventId}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccess('Event deleted successfully');
            // Remove row from table
            const row = document.querySelector(`tr[data-id="${eventId}"]`);
            if (row) {
                row.remove();
            }
        } else {
            showError(data.message || 'Error deleting event');
        }
    })
    .catch(error => {
        showError('Error deleting event');
        console.error('Error:', error);
    });
}

// Edit event
function editEvent(eventId) {
    // Fetch event data
    fetch(`admin/events.php?id=${eventId}`)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Populate form with event data
            const form = document.getElementById('eventForm');
            form.elements['name'].value = data.event.name;
            form.elements['category'].value = data.event.category;
            form.elements['status'].value = data.event.status;
            form.elements['date'].value = data.event.date;
            form.elements['time'].value = data.event.time;
            form.elements['location'].value = data.event.location;
            form.elements['description'].value = data.event.description;
            
            // Set form action
            form.setAttribute('data-event-id', eventId);
            
            // Open modal
            openModal('eventModal');
        } else {
            showError(data.message || 'Error loading event');
        }
    })
    .catch(error => {
        showError('Error loading event');
        console.error('Error:', error);
    });
}

// View event details
function viewEvent(eventId) {
    // Fetch event details
    fetch(`admin/events.php?id=${eventId}`)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Populate modal with event details
            const modal = document.getElementById('viewEventModal');
            modal.querySelector('.event-name').textContent = data.event.name;
            modal.querySelector('.event-category').textContent = data.event.category;
            modal.querySelector('.event-status').textContent = data.event.status;
            modal.querySelector('.event-date').textContent = data.event.date;
            modal.querySelector('.event-time').textContent = data.event.time;
            modal.querySelector('.event-location').textContent = data.event.location;
            modal.querySelector('.event-description').textContent = data.event.description;
            
            // Open modal
            openModal('viewEventModal');
        } else {
            showError(data.message || 'Error loading event');
        }
    })
    .catch(error => {
        showError('Error loading event');
        console.error('Error:', error);
    });
} 
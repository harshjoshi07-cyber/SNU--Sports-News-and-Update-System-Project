document.addEventListener('DOMContentLoaded', function() {
    // Create modal HTML
    const modalHTML = `
        <div class="event-modal">
            <div class="event-modal-content">
                <span class="close-modal">&times;</span>
                <div class="event-details">
                    <h2></h2>
                    <div class="event-info"></div>
                    <div class="event-description"></div>
                </div>
                <div class="register-form">
                    <h3>Register for Event</h3>
                    <form id="eventRegistrationForm">
                        <div class="form-group">
                            <label for="name">Full Name</label>
                            <input type="text" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" required>
                        </div>
                        <div class="form-group">
                            <label for="age">Age</label>
                            <input type="number" id="age" name="age" required>
                        </div>
                        <div class="form-group">
                            <label for="gender">Gender</label>
                            <select id="gender" name="gender" required>
                                <option value="">Select Gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="address">Address</label>
                            <textarea id="address" name="address" rows="3" required></textarea>
                        </div>
                        <button type="submit" class="register-btn">Register Now</button>
                    </form>
                    <div class="success-message">
                        <i class="fas fa-check-circle"></i>
                        <h3>Registration Successful!</h3>
                        <p>You have successfully registered for this event.</p>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Add modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);

    const modal = document.querySelector('.event-modal');
    const closeBtn = document.querySelector('.close-modal');
    const form = document.getElementById('eventRegistrationForm');
    const successMessage = document.querySelector('.success-message');

    // Event card click handler
    document.querySelectorAll('.event-card').forEach(card => {
        const registerIcon = card.querySelector('.register-icon');
        registerIcon.addEventListener('click', (e) => {
            e.preventDefault();
            const eventTitle = card.querySelector('h3').textContent;
            const eventDate = card.querySelector('.event-date').textContent;
            const eventLocation = card.querySelector('.event-location').textContent;
            const eventDescription = card.querySelector('p').textContent;

            // Populate modal with event details
            modal.querySelector('h2').textContent = eventTitle;
            modal.querySelector('.event-info').innerHTML = `
                <div class="info-item">
                    <i class="fas fa-calendar"></i>
                    <span>${eventDate}</span>
                </div>
                <div class="info-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${eventLocation}</span>
                </div>
            `;
            modal.querySelector('.event-description').textContent = eventDescription;

            // Show modal
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
        });
    });

    // Close modal
    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    });

    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });

    // Form submission
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Here you would typically send the form data to your server
        // For now, we'll just show the success message
        form.style.display = 'none';
        successMessage.style.display = 'block';

        // Update the register icon to show registered status
        const eventTitle = modal.querySelector('h2').textContent;
        document.querySelectorAll('.event-card').forEach(card => {
            if (card.querySelector('h3').textContent === eventTitle) {
                const registerIcon = card.querySelector('.register-icon');
                registerIcon.innerHTML = '<i class="fas fa-check"></i>';
                registerIcon.style.background = 'var(--success-color)';
            }
        });

        // Reset form and close modal after 3 seconds
        setTimeout(() => {
            form.reset();
            form.style.display = 'block';
            successMessage.style.display = 'none';
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }, 3000);
    });
}); 
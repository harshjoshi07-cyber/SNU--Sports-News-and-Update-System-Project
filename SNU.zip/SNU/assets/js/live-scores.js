document.addEventListener('DOMContentLoaded', function() {
    // Initialize live scores functionality
    const liveScores = {
        init: function() {
            this.cacheElements();
            this.bindEvents();
            this.showInitialSport();
        },

        cacheElements: function() {
            this.sportTabs = document.querySelectorAll('.sport-tab');
            this.sportScores = document.querySelectorAll('.sport-scores');
            this.scoreCards = document.querySelectorAll('.score-card');
        },

        bindEvents: function() {
            this.sportTabs.forEach(tab => {
                tab.addEventListener('click', () => this.switchSport(tab));
            });

            // Add hover effects to score cards
            this.scoreCards.forEach(card => {
                card.addEventListener('mouseenter', () => this.animateCard(card, true));
                card.addEventListener('mouseleave', () => this.animateCard(card, false));
            });
        },

        showInitialSport: function() {
            const initialTab = document.querySelector('.sport-tab.active');
            if (initialTab) {
                this.switchSport(initialTab);
            } else if (this.sportTabs.length > 0) {
                this.sportTabs[0].classList.add('active');
                this.switchSport(this.sportTabs[0]);
            }
        },

        switchSport: function(selectedTab) {
            // Remove active class from all tabs
            this.sportTabs.forEach(tab => tab.classList.remove('active'));
            
            // Add active class to selected tab
            selectedTab.classList.add('active');
            
            // Get the sport type from data attribute
            const sportType = selectedTab.dataset.sport;
            
            // Hide all score sections
            this.sportScores.forEach(section => {
                section.classList.remove('active');
            });
            
            // Show selected sport's scores
            const selectedScores = document.querySelector(`.sport-scores[data-sport="${sportType}"]`);
            if (selectedScores) {
                selectedScores.classList.add('active');
            }
        },

        animateCard: function(card, isHovering) {
            if (isHovering) {
                card.style.transform = 'translateY(-5px)';
                card.style.boxShadow = '0 10px 20px rgba(0, 0, 0, 0.1)';
            } else {
                card.style.transform = 'translateY(0)';
                card.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.05)';
            }
        },

        // Function to update scores (can be called periodically)
        updateScores: function() {
            // This would be used to fetch real-time updates
            // For demo purposes, we'll just animate the existing scores
            this.scoreCards.forEach(card => {
                if (card.classList.contains('active')) {
                    card.classList.remove('active');
                    setTimeout(() => card.classList.add('active'), 50);
                }
            });
        }
    };

    // Initialize live scores
    liveScores.init();

    // Set up periodic updates (every 30 seconds)
    setInterval(() => liveScores.updateScores(), 30000);
}); 
document.addEventListener('DOMContentLoaded', function() {
    // Initialize AOS
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true,
        mirror: false
    });

    // Mobile Navigation Toggle
    const mobileNavToggle = document.createElement('button');
    mobileNavToggle.className = 'mobile-nav-toggle';
    mobileNavToggle.innerHTML = '<span></span><span></span><span></span>';
    document.querySelector('.navbar').prepend(mobileNavToggle);

    mobileNavToggle.addEventListener('click', function() {
        document.querySelector('.nav-links').classList.toggle('active');
        this.classList.toggle('active');
    });

    // Smooth Scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Theme Toggle
    const themeToggle = document.getElementById('theme-toggle');
    const body = document.body;
    const icon = themeToggle.querySelector('i');

    // Check for saved theme preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        body.setAttribute('data-theme', savedTheme);
        icon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }

    themeToggle.addEventListener('click', () => {
        const currentTheme = body.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        body.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        icon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    });

    // Image hover effects
    const images = document.querySelectorAll('.news-img, .event-img');
    images.forEach(img => {
        img.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.05)';
            this.style.transition = 'transform 0.3s ease';
        });

        img.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });

    // Animate cards on scroll
    const cards = document.querySelectorAll('.news-card, .event-card');
    const animateCards = () => {
        cards.forEach(card => {
            const cardTop = card.getBoundingClientRect().top;
            const triggerBottom = window.innerHeight * 0.8;

            if (cardTop < triggerBottom) {
                card.classList.add('show');
            }
        });
    };

    window.addEventListener('scroll', animateCards);
    animateCards(); // Initial check

    // Animate section headers
    const headers = document.querySelectorAll('.section-header');
    const animateHeaders = () => {
        headers.forEach(header => {
            const headerTop = header.getBoundingClientRect().top;
            const triggerBottom = window.innerHeight * 0.9;

            if (headerTop < triggerBottom) {
                header.classList.add('show');
            }
        });
    };

    window.addEventListener('scroll', animateHeaders);
    animateHeaders(); // Initial check

    // News and Events Loading with loading animation
    async function loadContent() {
        try {
            // Show loading spinner
            const newsGrid = document.querySelector('.news-grid');
            if (newsGrid) {
                newsGrid.innerHTML = '<div class="spinner"></div>';
            }

        // Fetch latest news
            const newsResponse = await fetch('api/news.php');
            const newsData = await newsResponse.json();

            if (newsGrid && newsData.length > 0) {
                newsGrid.innerHTML = newsData.map((news, index) => `
                    <div class="news-card" data-aos="fade-up" data-aos-delay="${index * 100}">
                        <img src="${news.image}" alt="${news.title}" class="news-img">
                            <div class="card-content">
                                <h3>${news.title}</h3>
                                <p>${news.excerpt}</p>
                                <a href="news/${news.id}" class="btn btn-outline">Read More</a>
                            </div>
                        </div>
                    `).join('');

                // Refresh AOS
                AOS.refresh();
                }
        } catch (error) {
            console.error('Error loading content:', error);
        }
    }

    // Call loadContent initially
    loadContent();

    // Show notification function with animation
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Trigger animation
        setTimeout(() => notification.classList.add('show'), 10);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    // Form Validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!this.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            this.classList.add('was-validated');
        });
    });

    // Search Functionality
    const searchForm = document.querySelector('.search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const searchTerm = this.querySelector('input[type="search"]').value;
            // Implement search functionality
            console.log('Searching for:', searchTerm);
        });
    }

    // Event Registration Form
    const registrationForm = document.querySelector('.registration-form');
    if (registrationForm) {
        registrationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            fetch('api/register-event.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification('Registration successful!', 'success');
                } else {
                    showNotification(data.message || 'Registration failed', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('An error occurred', 'error');
            });
        });
    }
}); 
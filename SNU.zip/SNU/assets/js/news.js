document.addEventListener('DOMContentLoaded', function() {
    // News source switching
    const newsTabs = document.querySelectorAll('.news-tab');
    const newsSources = document.querySelectorAll('.news-source');
    
    newsTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove active class from all tabs
            newsTabs.forEach(t => t.classList.remove('active'));
            // Add active class to clicked tab
            tab.classList.add('active');
            
            const source = tab.dataset.source;
            
            // Handle "All News" tab
            if (source === 'all') {
                newsSources.forEach(s => s.style.display = 'grid');
            } else {
                // Hide all sources
                newsSources.forEach(s => s.style.display = 'none');
                // Show selected source
                document.querySelector(`.news-source.${source}`).style.display = 'grid';
            }
        });
    });

    // Auto-refresh functionality
    let refreshInterval;
    const refreshTime = 300000; // 5 minutes
    
    function startAutoRefresh() {
        refreshInterval = setInterval(refreshNews, refreshTime);
    }
    
    function refreshNews() {
        const refreshButton = document.querySelector('.refresh-button');
        if (refreshButton) {
            refreshButton.classList.add('loading');
        }
        
        fetch('includes/news-api.php')
            .then(response => response.text())
            .then(html => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const newNewsContainer = doc.querySelector('.news-container');
                
                if (newNewsContainer) {
                    document.querySelector('.news-container').innerHTML = newNewsContainer.innerHTML;
                    showRefreshIndicator();
                }
            })
            .catch(error => {
                console.error('Error refreshing news:', error);
                showErrorIndicator();
            })
            .finally(() => {
                if (refreshButton) {
                    refreshButton.classList.remove('loading');
                }
            });
    }
    
    function showRefreshIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'refresh-indicator';
        indicator.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <span>News Updated</span>
        `;
        
        document.body.appendChild(indicator);
        
        setTimeout(() => {
            indicator.remove();
        }, 3000);
    }
    
    function showErrorIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'refresh-indicator error';
        indicator.innerHTML = `
            <i class="fas fa-exclamation-circle"></i>
            <span>Error Updating News</span>
        `;
        
        document.body.appendChild(indicator);
        
        setTimeout(() => {
            indicator.remove();
        }, 3000);
    }
    
    // Create refresh button
    const refreshButton = document.createElement('button');
    refreshButton.className = 'refresh-button';
    refreshButton.innerHTML = '<i class="fas fa-sync-alt"></i>';
    refreshButton.title = 'Refresh News';
    refreshButton.addEventListener('click', () => {
        clearInterval(refreshInterval);
        refreshNews();
        startAutoRefresh();
    });
    
    document.body.appendChild(refreshButton);
    
    // Start auto-refresh when page loads
    startAutoRefresh();
    
    // Video player for live news
    const videoModal = document.createElement('div');
    videoModal.className = 'video-modal';
    videoModal.innerHTML = `
        <div class="video-modal-content">
            <span class="close-modal">&times;</span>
            <div class="video-container"></div>
        </div>
    `;
    
    document.body.appendChild(videoModal);
    
    // Handle video clicks
    document.addEventListener('click', (e) => {
        if (e.target.closest('.read-more') && e.target.closest('.news-card').querySelector('.live-badge')) {
            const videoUrl = e.target.closest('.read-more').href;
            openVideoModal(videoUrl);
        }
    });
    
    // Close modal
    videoModal.querySelector('.close-modal').addEventListener('click', () => {
        videoModal.style.display = 'none';
        const videoContainer = videoModal.querySelector('.video-container');
        videoContainer.innerHTML = '';
    });
    
    function openVideoModal(videoUrl) {
        const videoId = getYouTubeVideoId(videoUrl);
        const videoContainer = videoModal.querySelector('.video-container');
        
        videoContainer.innerHTML = `
            <iframe 
                width="100%" 
                height="100%" 
                src="https://www.youtube.com/embed/${videoId}?autoplay=1" 
                frameborder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen>
            </iframe>
        `;
        
        videoModal.style.display = 'flex';
    }
    
    function getYouTubeVideoId(url) {
        const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
        const match = url.match(regExp);
        return (match && match[2].length === 11) ? match[2] : null;
    }
}); 
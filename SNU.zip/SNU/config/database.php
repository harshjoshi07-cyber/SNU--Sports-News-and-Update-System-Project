<?php
// Database configuration
$host = 'localhost';
$dbname = 'sportshub';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    // Log the error but don't display it to users
    error_log("Database connection failed: " . $e->getMessage());
    // Continue execution without database connection
 
}
?> 

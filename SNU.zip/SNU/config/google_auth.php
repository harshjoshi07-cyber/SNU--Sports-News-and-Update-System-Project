<?php
require_once 'vendor/autoload.php';

$client = new Google_Client();
$client->setClientId('YOUR_GOOGLE_CLIENT_ID');
$client->setClientSecret('YOUR_GOOGLE_CLIENT_SECRET');
$client->setRedirectUri('http://localhost/SNU/user/google_callback.php');
$client->addScope('email');
$client->addScope('profile');

// Helper function to get Google login URL
function getGoogleLoginUrl() {
    global $client;
    return $client->createAuthUrl();
}

// Helper function to handle Google callback
function handleGoogleCallback($code) {
    global $client;
    try {
        $token = $client->fetchAccessTokenWithAuthCode($code);
        $client->setAccessToken($token);
        
        $google_oauth = new Google_Service_Oauth2($client);
        $google_account_info = $google_oauth->userinfo->get();
        
        return [
            'email' => $google_account_info->email,
            'name' => $google_account_info->name,
            'google_id' => $google_account_info->id
        ];
    } catch (Exception $e) {
        return false;
    }
}
?> 
-- Create news_articles table
CREATE TABLE IF NOT EXISTS news_articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    excerpt VARCHAR(500) NOT NULL,
    category VARCHAR(50) NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    author_name VARCHAR(100) NOT NULL,
    author_image VARCHAR(255) NOT NULL,
    published_date DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample news articles
INSERT INTO news_articles (title, content, excerpt, category, image_url, author_name, author_image, published_date) VALUES
(
    'Champions League Final: Real Madrid vs Manchester City',
    'The stage is set for an epic showdown between two European giants in the Champions League final. Real Madrid\'s experience against Manchester City\'s attacking prowess promises a thrilling match. Both teams have shown exceptional form throughout the tournament, with Real Madrid\'s dramatic comebacks and Manchester City\'s dominant performances. The final will be played at the iconic Wembley Stadium, adding another chapter to the rich history of this prestigious competition. Key players to watch include Vinicius Jr. for Real Madrid and Erling Haaland for Manchester City. The tactical battle between Carlo Ancelotti and Pep Guardiola will be fascinating to observe.',
    'The stage is set for an epic showdown between two European giants in the Champions League final. Real Madrid\'s experience against Manchester City\'s attacking prowess promises a thrilling match.',
    'Football',
    'assets/images/news/champions-league.jpg',
    'John Doe',
    'assets/images/authors/john-doe.jpg',
    '2024-05-15 10:00:00'
),
(
    'NBA Playoffs: Latest Updates and Predictions',
    'As the NBA playoffs heat up, teams are giving their all to secure a spot in the finals. Expert analysis and predictions for the upcoming crucial matches. The Eastern Conference has seen surprising performances from underdog teams, while the Western Conference continues to showcase intense competition between traditional powerhouses. Key matchups to watch include the battle of the big men in the paint and the three-point shooting contests that could decide crucial games. Teams are adapting their strategies based on previous matchups, making each game a unique tactical challenge.',
    'As the NBA playoffs heat up, teams are giving their all to secure a spot in the finals. Expert analysis and predictions for the upcoming crucial matches.',
    'Basketball',
    'assets/images/news/nba-playoffs.jpg',
    'Jane Smith',
    'assets/images/authors/jane-smith.jpg',
    '2024-05-14 15:30:00'
),
(
    'Tennis Grand Slam: French Open Preview',
    'The French Open is just around the corner, and tennis fans are eagerly awaiting. Top players prepare for the clay court challenge at Roland Garros. The tournament promises to be particularly exciting this year, with several players in peak form and the potential for new champions to emerge. The unique challenges of clay court tennis will test players\' endurance and tactical abilities. Key storylines include the return of former champions and the rise of young talents looking to make their mark on the sport\'s biggest stage.',
    'The French Open is just around the corner, and tennis fans are eagerly awaiting. Top players prepare for the clay court challenge at Roland Garros.',
    'Tennis',
    'assets/images/news/tennis-grand-slam.jpg',
    'Mike Wilson',
    'assets/images/authors/mike-wilson.jpg',
    '2024-05-13 09:15:00'
); 
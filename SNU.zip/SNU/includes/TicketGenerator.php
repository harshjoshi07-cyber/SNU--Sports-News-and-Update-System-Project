<?php
class TicketGenerator {
    private $event;
    private $registration;

    public function __construct($event, $registration) {
        $this->event = $event;
        $this->registration = $registration;
    }

    public function generateTicket() {
        // Generate a unique ticket ID
        $ticketId = uniqid('TICKET-', true);
        
        // Create HTML content for the ticket
        $html = $this->generateTicketHTML($ticketId);
        
        return $html;
    }

    private function generateTicketHTML($ticketId) {
        $additionalData = json_decode($this->registration['additional_data'] ?? '{}', true);
        
        $html = '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Event Ticket - ' . htmlspecialchars($this->event['name']) . '</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 0;
                    padding: 20px;
                    color: #333;
                }
                .ticket {
                    max-width: 800px;
                    margin: 0 auto;
                    border: 2px solid #333;
                    border-radius: 10px;
                    overflow: hidden;
                    box-shadow: 0 0 10px rgba(0,0,0,0.1);
                }
                .ticket-header {
                    background-color: #1a237e;
                    color: white;
                    padding: 20px;
                    text-align: center;
                }
                .ticket-body {
                    padding: 20px;
                }
                .ticket-footer {
                    background-color: #f5f5f5;
                    padding: 15px;
                    text-align: center;
                    border-top: 1px solid #ddd;
                }
                .ticket-info {
                    display: flex;
                    flex-wrap: wrap;
                    margin-bottom: 20px;
                }
                .info-group {
                    flex: 1 0 50%;
                    margin-bottom: 15px;
                }
                .info-label {
                    font-weight: bold;
                    color: #666;
                }
                .qr-code {
                    text-align: center;
                    margin: 20px 0;
                }
                .qr-code img {
                    max-width: 150px;
                }
                .ticket-id {
                    text-align: center;
                    font-size: 12px;
                    color: #666;
                    margin-top: 10px;
                }
                @media print {
                    body {
                        padding: 0;
                    }
                    .ticket {
                        border: none;
                        box-shadow: none;
                    }
                }
            </style>
        </head>
        <body>
            <div class="ticket">
                <div class="ticket-header">
                    <h1>' . htmlspecialchars($this->event['name']) . '</h1>
                    <p>EVENT TICKET</p>
                </div>
                <div class="ticket-body">
                    <div class="ticket-info">
                        <div class="info-group">
                            <div class="info-label">Event:</div>
                            <div>' . htmlspecialchars($this->event['name']) . '</div>
                        </div>
                        <div class="info-group">
                            <div class="info-label">Date:</div>
                            <div>' . htmlspecialchars($this->event['date']) . '</div>
                        </div>
                        <div class="info-group">
                            <div class="info-label">Time:</div>
                            <div>' . htmlspecialchars($this->event['time']) . '</div>
                        </div>
                        <div class="info-group">
                            <div class="info-label">Location:</div>
                            <div>' . htmlspecialchars($this->event['location']) . '</div>
                        </div>
                    </div>
                    
                    <div class="ticket-info">
                        <div class="info-group">
                            <div class="info-label">Attendee Name:</div>
                            <div>' . htmlspecialchars($this->registration['name']) . '</div>
                        </div>
                        <div class="info-group">
                            <div class="info-label">Email:</div>
                            <div>' . htmlspecialchars($this->registration['email']) . '</div>
                        </div>
                        <div class="info-group">
                            <div class="info-label">Phone:</div>
                            <div>' . htmlspecialchars($this->registration['phone']) . '</div>
                        </div>
                        <div class="info-group">
                            <div class="info-label">Registration ID:</div>
                            <div>' . htmlspecialchars($this->registration['id']) . '</div>
                        </div>
                    </div>';
        
        // Add event-specific information
        if (!empty($additionalData)) {
            $html .= '<div class="ticket-info">';
            foreach ($additionalData as $key => $value) {
                $label = ucwords(str_replace('_', ' ', $key));
                $html .= '
                    <div class="info-group">
                        <div class="info-label">' . htmlspecialchars($label) . ':</div>
                        <div>' . htmlspecialchars($value) . '</div>
                    </div>';
            }
            $html .= '</div>';
        }
        
        $html .= '
                    <div class="qr-code">
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=' . urlencode($ticketId) . '" alt="Ticket QR Code">
                    </div>
                    <div class="ticket-id">
                        Ticket ID: ' . $ticketId . '
                    </div>
                </div>
                <div class="ticket-footer">
                    <p>Please present this ticket at the event entrance.</p>
                    <p>This ticket is non-transferable and valid only for the registered attendee.</p>
                </div>
            </div>
        </body>
        </html>';
        
        return $html;
    }

    public function downloadTicket($filename = 'ticket.pdf') {
        $html = $this->generateTicket();
        
        // Set headers for HTML download
        header('Content-Type: text/html');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        // Output the HTML
        echo $html;
        exit;
    }
}
?> 
<footer class="main-footer">
    <div class="footer-content">
        <div class="footer-section" data-aos="fade-up" data-aos-delay="100">
            <h3>About Us</h3>
            <p>Your premier destination for sports news and events.</p>
        </div>
        <div class="footer-section" data-aos="fade-up" data-aos-delay="200">
            <h3>Quick Links</h3>
            <ul>
                <li><a href="news.php">News</a></li>
                <li><a href="events.php">Events</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="footer-section" data-aos="fade-up" data-aos-delay="300">
            <h3>Connect With Us</h3>
            <div class="social-links">
                <a href="#" class="social-icon"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
                <a href="#" class="social-icon"><i class="fab fa-instagram"></i></a>
                <a href="#" class="social-icon"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; 2024 SportsHub. All rights reserved.</p>
    </div>
</footer> 
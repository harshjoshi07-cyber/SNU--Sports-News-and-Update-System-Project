<?php
// Google OAuth Configuration
$google_client_id = 'YOUR_GOOGLE_CLIENT_ID';
$google_client_secret = 'YOUR_GOOGLE_CLIENT_SECRET';
$google_redirect_uri = 'http://localhost/SNU/user/google_callback.php';

/**
 * Handle Google OAuth callback
 * 
 * @param string $code Authorization code from Google
 * @return array|false User information or false on failure
 */
function handleGoogleCallback($code) {
    global $google_client_id, $google_client_secret, $google_redirect_uri;
    
    // Exchange authorization code for access token
    $token_url = 'https://oauth2.googleapis.com/token';
    $data = [
        'code' => $code,
        'client_id' => $google_client_id,
        'client_secret' => $google_client_secret,
        'redirect_uri' => $google_redirect_uri,
        'grant_type' => 'authorization_code'
    ];
    
    $ch = curl_init($token_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code !== 200) {
        error_log("Google token exchange failed: " . $response);
        return false;
    }
    
    $token_data = json_decode($response, true);
    $access_token = $token_data['access_token'];
    
    // Get user information
    $user_info_url = 'https://www.googleapis.com/oauth2/v2/userinfo';
    $ch = curl_init($user_info_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $access_token
    ]);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code !== 200) {
        error_log("Google user info request failed: " . $response);
        return false;
    }
    
    $user_data = json_decode($response, true);
    
    return [
        'google_id' => $user_data['id'],
        'name' => $user_data['name'],
        'email' => $user_data['email'],
        'picture' => $user_data['picture'] ?? null
    ];
}

/**
 * Generate Google OAuth URL
 * 
 * @return string Google OAuth URL
 */
function getGoogleAuthUrl() {
    global $google_client_id, $google_redirect_uri;
    
    $auth_url = 'https://accounts.google.com/o/oauth2/auth';
    $params = [
        'client_id' => $google_client_id,
        'redirect_uri' => $google_redirect_uri,
        'response_type' => 'code',
        'scope' => 'email profile',
        'access_type' => 'online',
        'prompt' => 'select_account'
    ];
    
    return $auth_url . '?' . http_build_query($params);
} 
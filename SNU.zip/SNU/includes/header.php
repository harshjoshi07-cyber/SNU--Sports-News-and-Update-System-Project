<?php
// Get current page for active menu highlighting
$current_page = basename($_SERVER['PHP_SELF']);
?>
<header class="main-header">
    <nav class="navbar">
        <div class="logo" data-aos="fade-right" data-aos-duration="1000">
            <img src="https://cdn-icons-png.flaticon.com/512/2936/2936886.png" alt="SportsHub Logo" class="logo-img">
            <h1>SportsHub</h1>
        </div>
        <ul class="nav-links">
            <li><a href="index.php" <?php echo ($current_page == 'index.php') ? 'class="active"' : ''; ?>>Home</a></li>
            <li><a href="news.php" <?php echo ($current_page == 'news.php') ? 'class="active"' : ''; ?>>News</a></li>
            <li><a href="events.php" <?php echo ($current_page == 'events.php') ? 'class="active"' : ''; ?>>Events</a></li>
            <li><a href="about.php" <?php echo ($current_page == 'about.php') ? 'class="active"' : ''; ?>>About</a></li>
            <li><a href="contact.php" <?php echo ($current_page == 'contact.php') ? 'class="active"' : ''; ?>>Contact</a></li>
        </ul>
        <div class="auth-buttons">
            <button id="theme-toggle" class="theme-toggle" aria-label="Toggle dark mode">
                <i class="fas fa-moon"></i>
            </button>
            <a href="user/login.php" class="btn btn-outline">Login</a>
            <a href="user/register.php" class="btn btn-primary">Register</a>
        </div>
    </nav>
</header> 
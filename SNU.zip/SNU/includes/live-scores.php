<?php
// Live Scores API Handler
class LiveScores {
    private $cricbuzz_api_key = 'YOUR_CRICBUZZ_API_KEY';
    private $sportskeeda_api_key = 'YOUR_SPORTSKEEDA_API_KEY';
    private $cricbuzz_base_url = 'https://cricbuzz-cricket.p.rapidapi.com/';
    private $sportskeeda_base_url = 'https://api.sportskeeda.com/v1/';

    // Demo Live Scores Data
    private $demo_cricket_matches = [
        [
            'matchId' => 1,
            'seriesName' => 'ICC World Cup 2024',
            'status' => 'LIVE',
            'team1' => [
                'name' => 'India',
                'score' => '245/3',
                'overs' => '35.2'
            ],
            'team2' => [
                'name' => 'Australia',
                'score' => '189/7',
                'overs' => '30.0'
            ],
            'venue' => 'Melbourne Cricket Ground',
            'startTime' => '2024-03-15 10:30:00'
        ],
        [
            'matchId' => 2,
            'seriesName' => 'IPL 2024',
            'status' => 'LIVE',
            'team1' => [
                'name' => 'Mumbai Indians',
                'score' => '165/4',
                'overs' => '18.0'
            ],
            'team2' => [
                'name' => 'Chennai Super Kings',
                'score' => '142/6',
                'overs' => '16.2'
            ],
            'venue' => 'Wankhede Stadium',
            'startTime' => '2024-03-15 19:30:00'
        ]
    ];

    private $demo_football_matches = [
        [
            'id' => 1,
            'league' => ['name' => 'Premier League'],
            'status' => 'LIVE',
            'homeTeam' => [
                'name' => 'Manchester United',
                'score' => '2'
            ],
            'awayTeam' => [
                'name' => 'Liverpool',
                'score' => '1'
            ],
            'venue' => 'Old Trafford',
            'time' => '90+3'
        ],
        [
            'id' => 2,
            'league' => ['name' => 'La Liga'],
            'status' => 'LIVE',
            'homeTeam' => [
                'name' => 'Real Madrid',
                'score' => '3'
            ],
            'awayTeam' => [
                'name' => 'Barcelona',
                'score' => '2'
            ],
            'venue' => 'Santiago Bernabeu',
            'time' => '75'
        ]
    ];

    private $demo_basketball_matches = [
        [
            'id' => 1,
            'league' => ['name' => 'NBA'],
            'status' => 'LIVE',
            'homeTeam' => [
                'name' => 'LA Lakers',
                'score' => '98'
            ],
            'awayTeam' => [
                'name' => 'Boston Celtics',
                'score' => '95'
            ],
            'venue' => 'Staples Center',
            'time' => 'Q4 8:32'
        ],
        [
            'id' => 2,
            'league' => ['name' => 'NBA'],
            'status' => 'LIVE',
            'homeTeam' => [
                'name' => 'Golden State Warriors',
                'score' => '112'
            ],
            'awayTeam' => [
                'name' => 'Chicago Bulls',
                'score' => '108'
            ],
            'venue' => 'Chase Center',
            'time' => 'Q4 2:15'
        ]
    ];

    private $demo_tennis_matches = [
        [
            'id' => 1,
            'tournament' => ['name' => 'Wimbledon 2024'],
            'status' => 'LIVE',
            'player1' => [
                'name' => 'Novak Djokovic',
                'score' => '6-4, 4-6, 5-3'
            ],
            'player2' => [
                'name' => 'Rafael Nadal',
                'score' => '4-6, 6-4, 3-5'
            ],
            'venue' => 'Centre Court',
            'time' => '3rd Set'
        ],
        [
            'id' => 2,
            'tournament' => ['name' => 'US Open 2024'],
            'status' => 'LIVE',
            'player1' => [
                'name' => 'Serena Williams',
                'score' => '6-3, 4-6, 5-2'
            ],
            'player2' => [
                'name' => 'Naomi Osaka',
                'score' => '3-6, 6-4, 2-5'
            ],
            'venue' => 'Arthur Ashe Stadium',
            'time' => '3rd Set'
        ]
    ];

    public function getCricketScores() {
        return ['matches' => $this->demo_cricket_matches];
    }

    public function getFootballScores() {
        return ['matches' => $this->demo_football_matches];
    }

    public function getBasketballScores() {
        return ['matches' => $this->demo_basketball_matches];
    }

    public function getTennisScores() {
        return ['matches' => $this->demo_tennis_matches];
    }

    // Function to format cricket match data
    public function formatCricketMatch($match) {
        return [
            'id' => $match['matchId'],
            'series' => $match['seriesName'],
            'status' => $match['status'],
            'teams' => [
                'home' => [
                    'name' => $match['team1']['name'],
                    'score' => $match['team1']['score'],
                    'overs' => $match['team1']['overs']
                ],
                'away' => [
                    'name' => $match['team2']['name'],
                    'score' => $match['team2']['score'],
                    'overs' => $match['team2']['overs']
                ]
            ],
            'venue' => $match['venue'],
            'startTime' => $match['startTime']
        ];
    }

    // Function to format football match data
    public function formatFootballMatch($match) {
        return [
            'id' => $match['id'],
            'league' => $match['league']['name'],
            'status' => $match['status'],
            'teams' => [
                'home' => [
                    'name' => $match['homeTeam']['name'],
                    'score' => $match['homeTeam']['score']
                ],
                'away' => [
                    'name' => $match['awayTeam']['name'],
                    'score' => $match['awayTeam']['score']
                ]
            ],
            'venue' => $match['venue'],
            'time' => $match['time']
        ];
    }

    // Function to format basketball match data
    public function formatBasketballMatch($match) {
        return [
            'id' => $match['id'],
            'league' => $match['league']['name'],
            'status' => $match['status'],
            'teams' => [
                'home' => [
                    'name' => $match['homeTeam']['name'],
                    'score' => $match['homeTeam']['score']
                ],
                'away' => [
                    'name' => $match['awayTeam']['name'],
                    'score' => $match['awayTeam']['score']
                ]
            ],
            'venue' => $match['venue'],
            'time' => $match['time']
        ];
    }

    // Function to format tennis match data
    public function formatTennisMatch($match) {
        return [
            'id' => $match['id'],
            'tournament' => $match['tournament']['name'],
            'status' => $match['status'],
            'players' => [
                'player1' => [
                    'name' => $match['player1']['name'],
                    'score' => $match['player1']['score']
                ],
                'player2' => [
                    'name' => $match['player2']['name'],
                    'score' => $match['player2']['score']
                ]
            ],
            'venue' => $match['venue'],
            'time' => $match['time']
        ];
    }
}

// Function to display live scores
function displayLiveScores() {
    $live_scores = new LiveScores();
    ?>
    <section class="live-scores">
        <div class="container">
            <h2 class="section-title">Live Scores</h2>
            <div class="sports-tabs">
                <button class="sport-tab active" data-sport="cricket">
                    <i class="fas fa-cricket"></i> Cricket
                </button>
                <button class="sport-tab" data-sport="football">
                    <i class="fas fa-futbol"></i> Football
                </button>
                <button class="sport-tab" data-sport="basketball">
                    <i class="fas fa-basketball-ball"></i> Basketball
                </button>
                <button class="sport-tab" data-sport="tennis">
                    <i class="fas fa-table-tennis"></i> Tennis
                </button>
            </div>
            
            <div class="scores-container">
                <!-- Cricket Scores -->
                <div class="sport-scores active" id="cricket-scores">
                    <?php
                    $cricket_scores = $live_scores->getCricketScores();
                    if ($cricket_scores && isset($cricket_scores['matches'])) {
                        foreach ($cricket_scores['matches'] as $match) {
                            $formatted_match = $live_scores->formatCricketMatch($match);
                            ?>
                            <div class="score-card">
                                <div class="match-header">
                                    <span class="series"><?php echo $formatted_match['series']; ?></span>
                                    <span class="status"><?php echo $formatted_match['status']; ?></span>
                                </div>
                                <div class="match-teams">
                                    <div class="team">
                                        <span class="team-name"><?php echo $formatted_match['teams']['home']['name']; ?></span>
                                        <div class="score-details">
                                            <span class="score"><?php echo $formatted_match['teams']['home']['score']; ?></span>
                                            <span class="overs"><?php echo $formatted_match['teams']['home']['overs']; ?> overs</span>
                                        </div>
                                    </div>
                                    <div class="vs">VS</div>
                                    <div class="team">
                                        <span class="team-name"><?php echo $formatted_match['teams']['away']['name']; ?></span>
                                        <div class="score-details">
                                            <span class="score"><?php echo $formatted_match['teams']['away']['score']; ?></span>
                                            <span class="overs"><?php echo $formatted_match['teams']['away']['overs']; ?> overs</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="match-info">
                                    <span class="venue"><?php echo $formatted_match['venue']; ?></span>
                                    <span class="time"><?php echo date('H:i', strtotime($formatted_match['startTime'])); ?></span>
                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        echo '<p class="no-scores">No live cricket matches available</p>';
                    }
                    ?>
                </div>

                <!-- Football Scores -->
                <div class="sport-scores" id="football-scores">
                    <?php
                    $football_scores = $live_scores->getFootballScores();
                    if ($football_scores && isset($football_scores['matches'])) {
                        foreach ($football_scores['matches'] as $match) {
                            $formatted_match = $live_scores->formatFootballMatch($match);
                            ?>
                            <div class="score-card">
                                <div class="match-header">
                                    <span class="league"><?php echo $formatted_match['league']; ?></span>
                                    <span class="status"><?php echo $formatted_match['status']; ?></span>
                                </div>
                                <div class="match-teams">
                                    <div class="team">
                                        <span class="team-name"><?php echo $formatted_match['teams']['home']['name']; ?></span>
                                        <span class="score"><?php echo $formatted_match['teams']['home']['score']; ?></span>
                                    </div>
                                    <div class="vs">VS</div>
                                    <div class="team">
                                        <span class="team-name"><?php echo $formatted_match['teams']['away']['name']; ?></span>
                                        <span class="score"><?php echo $formatted_match['teams']['away']['score']; ?></span>
                                    </div>
                                </div>
                                <div class="match-info">
                                    <span class="venue"><?php echo $formatted_match['venue']; ?></span>
                                    <span class="time"><?php echo $formatted_match['time']; ?></span>
                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        echo '<p class="no-scores">No live football matches available</p>';
                    }
                    ?>
                </div>

                <!-- Basketball Scores -->
                <div class="sport-scores" id="basketball-scores">
                    <?php
                    $basketball_scores = $live_scores->getBasketballScores();
                    if ($basketball_scores && isset($basketball_scores['matches'])) {
                        foreach ($basketball_scores['matches'] as $match) {
                            $formatted_match = $live_scores->formatBasketballMatch($match);
                            ?>
                            <div class="score-card">
                                <div class="match-header">
                                    <span class="league"><?php echo $formatted_match['league']; ?></span>
                                    <span class="status"><?php echo $formatted_match['status']; ?></span>
                                </div>
                                <div class="match-teams">
                                    <div class="team">
                                        <span class="team-name"><?php echo $formatted_match['teams']['home']['name']; ?></span>
                                        <span class="score"><?php echo $formatted_match['teams']['home']['score']; ?></span>
                                    </div>
                                    <div class="vs">VS</div>
                                    <div class="team">
                                        <span class="team-name"><?php echo $formatted_match['teams']['away']['name']; ?></span>
                                        <span class="score"><?php echo $formatted_match['teams']['away']['score']; ?></span>
                                    </div>
                                </div>
                                <div class="match-info">
                                    <span class="venue"><?php echo $formatted_match['venue']; ?></span>
                                    <span class="time"><?php echo $formatted_match['time']; ?></span>
                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        echo '<p class="no-scores">No live basketball matches available</p>';
                    }
                    ?>
                </div>

                <!-- Tennis Scores -->
                <div class="sport-scores" id="tennis-scores">
                    <?php
                    $tennis_scores = $live_scores->getTennisScores();
                    if ($tennis_scores && isset($tennis_scores['matches'])) {
                        foreach ($tennis_scores['matches'] as $match) {
                            $formatted_match = $live_scores->formatTennisMatch($match);
                            ?>
                            <div class="score-card">
                                <div class="match-header">
                                    <span class="tournament"><?php echo $formatted_match['tournament']; ?></span>
                                    <span class="status"><?php echo $formatted_match['status']; ?></span>
                                </div>
                                <div class="match-teams">
                                    <div class="team">
                                        <span class="player-name"><?php echo $formatted_match['players']['player1']['name']; ?></span>
                                        <span class="score"><?php echo $formatted_match['players']['player1']['score']; ?></span>
                                    </div>
                                    <div class="vs">VS</div>
                                    <div class="team">
                                        <span class="player-name"><?php echo $formatted_match['players']['player2']['name']; ?></span>
                                        <span class="score"><?php echo $formatted_match['players']['player2']['score']; ?></span>
                                    </div>
                                </div>
                                <div class="match-info">
                                    <span class="venue"><?php echo $formatted_match['venue']; ?></span>
                                    <span class="time"><?php echo $formatted_match['time']; ?></span>
                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        echo '<p class="no-scores">No live tennis matches available</p>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </section>
    <?php
}
?> 
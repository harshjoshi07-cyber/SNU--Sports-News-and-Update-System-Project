<?php
class NewsAPI {
    private $newsapi_key = 'YOUR_NEWSAPI_KEY';
    private $rapidapi_key = 'YOUR_RAPIDAPI_KEY';
    private $youtube_api_key = 'YOUR_YOUTUBE_API_KEY';

    public function getLatestSportsNews() {
        $sources = [
            'espn' => $this->getESPNNews(),
            'sportskeeda' => $this->getSportskeedaNews(),
            'cricbuzz' => $this->getCricbuzzNews(),
            'youtube' => $this->getYouTubeSportsNews()
        ];

        return $sources;
    }

    private function getESPNNews() {
        $url = "https://site.api.espn.com/apis/site/v2/sports/news";
        $response = $this->makeRequest($url);
        return $this->formatESPNNews($response);
    }

    private function getSportskeedaNews() {
        $url = "https://sportskeeda.p.rapidapi.com/news/list";
        $headers = [
            'X-RapidAPI-Key: ' . $this->rapidapi_key,
            'X-RapidAPI-Host: sportskeeda.p.rapidapi.com'
        ];
        $response = $this->makeRequest($url, $headers);
        return $this->formatSportskeedaNews($response);
    }

    private function getCricbuzzNews() {
        $url = "https://cricbuzz-cricket.p.rapidapi.com/news/v1/index";
        $headers = [
            'X-RapidAPI-Key: ' . $this->rapidapi_key,
            'X-RapidAPI-Host: cricbuzz-cricket.p.rapidapi.com'
        ];
        $response = $this->makeRequest($url, $headers);
        return $this->formatCricbuzzNews($response);
    }

    private function getYouTubeSportsNews() {
        $url = "https://www.googleapis.com/youtube/v3/search?part=snippet&q=sports+news&type=video&eventType=live&key=" . $this->youtube_api_key;
        $response = $this->makeRequest($url);
        return $this->formatYouTubeNews($response);
    }

    private function makeRequest($url, $headers = []) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        if (!empty($headers)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }
        $response = curl_exec($ch);
        curl_close($ch);
        return json_decode($response, true);
    }

    private function formatESPNNews($data) {
        $formatted = [];
        if (isset($data['articles'])) {
            foreach ($data['articles'] as $article) {
                $formatted[] = [
                    'title' => $article['title'],
                    'description' => $article['description'],
                    'url' => $article['url'],
                    'image' => $article['urlToImage'],
                    'source' => 'ESPN',
                    'publishedAt' => $article['publishedAt']
                ];
            }
        }
        return $formatted;
    }

    private function formatSportskeedaNews($data) {
        $formatted = [];
        if (isset($data['data'])) {
            foreach ($data['data'] as $article) {
                $formatted[] = [
                    'title' => $article['title'],
                    'description' => $article['description'],
                    'url' => $article['url'],
                    'image' => $article['image'],
                    'source' => 'Sportskeeda',
                    'publishedAt' => $article['published_at']
                ];
            }
        }
        return $formatted;
    }

    private function formatCricbuzzNews($data) {
        $formatted = [];
        if (isset($data['storyList'])) {
            foreach ($data['storyList'] as $story) {
                $formatted[] = [
                    'title' => $story['story']['hline'],
                    'description' => $story['story']['intro'],
                    'url' => $story['story']['url'],
                    'image' => $story['story']['image']['url'],
                    'source' => 'Cricbuzz',
                    'publishedAt' => $story['story']['pubTime']
                ];
            }
        }
        return $formatted;
    }

    private function formatYouTubeNews($data) {
        $formatted = [];
        if (isset($data['items'])) {
            foreach ($data['items'] as $video) {
                $formatted[] = [
                    'title' => $video['snippet']['title'],
                    'description' => $video['snippet']['description'],
                    'url' => 'https://www.youtube.com/watch?v=' . $video['id']['videoId'],
                    'image' => $video['snippet']['thumbnails']['high']['url'],
                    'source' => 'YouTube',
                    'publishedAt' => $video['snippet']['publishedAt'],
                    'isLive' => true
                ];
            }
        }
        return $formatted;
    }
}

function displayLatestNews() {
    $news_api = new NewsAPI();
    $news = $news_api->getLatestSportsNews();
    ?>
    <section class="latest-news">
        <div class="container">
            <h2 class="section-title">Latest Sports News</h2>
            <div class="news-tabs">
                <button class="news-tab active" data-source="all">All News</button>
                <button class="news-tab" data-source="espn">ESPN</button>
                <button class="news-tab" data-source="sportskeeda">Sportskeeda</button>
                <button class="news-tab" data-source="cricbuzz">Cricbuzz</button>
                <button class="news-tab" data-source="youtube">Live Videos</button>
            </div>
            
            <div class="news-container">
                <?php foreach ($news as $source => $articles): ?>
                    <div class="news-source <?php echo $source; ?>" style="display: <?php echo $source === 'espn' ? 'block' : 'none'; ?>">
                        <?php foreach ($articles as $article): ?>
                            <div class="news-card">
                                <div class="news-image">
                                    <img src="<?php echo $article['image']; ?>" alt="<?php echo $article['title']; ?>">
                                    <?php if (isset($article['isLive'])): ?>
                                        <span class="live-badge">LIVE</span>
                                    <?php endif; ?>
                                </div>
                                <div class="news-content">
                                    <h3><?php echo $article['title']; ?></h3>
                                    <p><?php echo $article['description']; ?></p>
                                    <div class="news-meta">
                                        <span class="source"><?php echo $article['source']; ?></span>
                                        <span class="time"><?php echo date('M d, Y H:i', strtotime($article['publishedAt'])); ?></span>
                                    </div>
                                    <a href="<?php echo $article['url']; ?>" class="read-more" target="_blank">
                                        <?php echo isset($article['isLive']) ? 'Watch Live' : 'Read More'; ?>
                                        <i class="fas fa-arrow-right"></i>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php
}
?> 
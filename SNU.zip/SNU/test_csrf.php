<?php
require_once 'includes/config.php';
session_start();

// Generate a new CSRF token
$csrf_token = generateCSRFToken();

// Display the token
echo "CSRF Token: " . $csrf_token . "<br>";
echo "Session ID: " . session_id() . "<br>";
echo "Session Status: " . session_status() . "<br>";

// Test verification
$is_valid = verifyCSRFToken($csrf_token);
echo "Token verification: " . ($is_valid ? "Valid" : "Invalid") . "<br>";

// Test with a different token
$fake_token = "fake_token";
$is_valid = verifyCSRFToken($fake_token);
echo "Fake token verification: " . ($is_valid ? "Valid" : "Invalid") . "<br>";

// Display session contents
echo "<pre>";
print_r($_SESSION);
echo "</pre>";
?> 
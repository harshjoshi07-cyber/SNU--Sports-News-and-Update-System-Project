<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

// Initialize database connection
$pdo = getDBConnection();
if (!$pdo) {
    die("Database connection failed. Please try again later.");
}

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    
    if (empty($email)) {
        $error = 'Please enter your email address';
    } else {
        try {
            // Check if email exists in database
            $stmt = $pdo->prepare("SELECT id, username FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                // Generate reset token
                $token = bin2hex(random_bytes(32));
                $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

                // Store token in database
                $stmt = $pdo->prepare("UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?");
                $stmt->execute([$token, $expires, $user['id']]);

                // Send reset email
                $reset_link = "http://" . $_SERVER['HTTP_HOST'] . "/SNU/user/reset-password.php?token=" . $token;
                $to = $email;
                $subject = "Password Reset Request";
                $message = "Hello " . $user['username'] . ",\n\n";
                $message .= "You have requested to reset your password. Click the link below to reset it:\n\n";
                $message .= $reset_link . "\n\n";
                $message .= "This link will expire in 1 hour.\n\n";
                $message .= "If you did not request this password reset, please ignore this email.\n\n";
                $message .= "Best regards,\nSports News & Updates Team";

                $headers = "From: noreply@sportsnews.com\r\n";
                $headers .= "Reply-To: noreply@sportsnews.com\r\n";
                $headers .= "X-Mailer: PHP/" . phpversion();

                if (mail($to, $subject, $message, $headers)) {
                    $success = 'Password reset link has been sent to your email address.';
                } else {
                    $error = 'Failed to send reset email. Please try again later.';
                }
            } else {
                $error = 'No account found with that email address.';
            }
        } catch (PDOException $e) {
            $error = 'An error occurred. Please try again later.';
        }
    }
}
?>

<div class="auth-wrapper">
    <div class="site-header">
        <div class="header-container">
            <a href="../index.php" class="site-logo">
                <img src="../assets/images/logo.png" alt="SportsHub Logo">
                <span>SportsHub</span>
            </a>
            <nav class="site-nav">
                <a href="../index.php">Home</a>
                <a href="../news.php">News</a>
                <a href="../events.php">Events</a>
                <a href="../contact.php">Contact</a>
            </nav>
        </div>
    </div>

    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-header">
                <div class="logo-container">
                    <div class="logo-wrapper">
                        <img src="../assets/images/logo.png" alt="SportsHub Logo" class="auth-logo">
                        <div class="logo-glow"></div>
                    </div>
                </div>
                <h2>Forgot Password</h2>
                <p class="auth-description">Enter your email address and we'll send you a link to reset your password.</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo $success; ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" action="forgot-password.php" class="auth-form">
                <div class="form-group">
                    <label for="email">
                        <i class="fas fa-envelope"></i>
                        Email Address
                    </label>
                    <div class="input-group">
                        <input type="email" id="email" name="email" class="form-control" required 
                               placeholder="Enter your email address">
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">
                    <span>Send Reset Link</span>
                    <i class="fas fa-arrow-right"></i>
                </button>
            </form>

            <div class="auth-links">
                <a href="login.php" class="back-link">
                    <i class="fas fa-arrow-left"></i>
                    Back to Login
                </a>
            </div>
        </div>
    </div>

    <footer class="site-footer">
        <div class="footer-content">
            <div class="footer-logo">
                <img src="../assets/images/logo.png" alt="SportsHub Logo">
                <span>SportsHub</span>
            </div>
            <div class="footer-links">
                <a href="../privacy.php">Privacy Policy</a>
                <span class="separator">•</span>
                <a href="../terms.php">Terms of Service</a>
                <span class="separator">•</span>
                <a href="../contact.php">Contact Us</a>
            </div>
            <div class="footer-social">
                <a href="#" class="social-link"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
            </div>
            <p class="footer-copyright">&copy; <?php echo date('Y'); ?> SportsHub. All rights reserved.</p>
        </div>
    </footer>
</div>

<style>
:root {
    --primary-color: #2c3e50;
    --secondary-color: #e74c3c;
    --accent-color: #3498db;
    --success-color: #2ecc71;
    --error-color: #e74c3c;
    --text-primary: #2c3e50;
    --text-secondary: #7f8c8d;
    --border-radius: 16px;
    --box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
    --transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    --gradient-primary: linear-gradient(135deg, #2c3e50, #3498db);
    --gradient-secondary: linear-gradient(135deg, #3498db, #e74c3c);
    --glass-bg: rgba(255, 255, 255, 0.95);
    --glass-border: rgba(255, 255, 255, 0.2);
    --header-height: 80px;
    --footer-height: 200px;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Open Sans', sans-serif;
    background: linear-gradient(135deg, #f5f7fa, #e5e9f2);
    min-height: 100vh;
    line-height: 1.6;
}

.auth-wrapper {
    padding-top: calc(var(--header-height) + 2rem);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
}

.auth-wrapper::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: url('../assets/images/pattern.svg') center/cover;
    opacity: 0.05;
    z-index: -1;
}

.auth-container {
    width: 100%;
    max-width: 480px;
    perspective: 1000px;
}

.auth-box {
    background: var(--glass-bg);
    padding: 3rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    position: relative;
    z-index: 1;
    transform-style: preserve-3d;
    transition: var(--transition);
    backdrop-filter: blur(10px);
    border: 1px solid var(--glass-border);
    overflow: hidden;
}

.auth-box:hover {
    transform: translateY(-5px) rotateX(2deg);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
}

.auth-box::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 5px;
    background: var(--gradient-primary);
    animation: gradientFlow 3s ease infinite;
    background-size: 200% 200%;
}

@keyframes gradientFlow {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

.logo-container {
    position: relative;
    margin-bottom: 2.5rem;
}

.logo-wrapper {
    position: relative;
    width: 100px;
    height: 100px;
    margin: 0 auto;
}

.auth-logo {
    width: 100%;
    height: 100%;
    object-fit: contain;
    position: relative;
    z-index: 2;
    filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.2));
    transition: var(--transition);
}

.logo-glow {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 120%;
    height: 120%;
    background: radial-gradient(circle, rgba(52, 152, 219, 0.2) 0%, transparent 70%);
    animation: glowPulse 2s ease-in-out infinite;
    z-index: 1;
}

@keyframes glowPulse {
    0% { transform: translate(-50%, -50%) scale(1); opacity: 0.5; }
    50% { transform: translate(-50%, -50%) scale(1.1); opacity: 0.8; }
    100% { transform: translate(-50%, -50%) scale(1); opacity: 0.5; }
}

.logo-wrapper:hover .auth-logo {
    transform: scale(1.1) rotate(5deg);
}

.auth-header {
    text-align: center;
    margin-bottom: 2.5rem;
}

.auth-header h2 {
    font-size: 2.2rem;
    color: var(--text-primary);
    margin-bottom: 1rem;
    font-weight: 700;
    letter-spacing: -0.5px;
}

.auth-description {
    color: var(--text-secondary);
    font-size: 1.1rem;
    max-width: 90%;
    margin: 0 auto;
}

.auth-form {
    margin-top: 2rem;
}

.form-group {
    margin-bottom: 2rem;
    position: relative;
}

.form-group label {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 0.8rem;
    color: var(--text-primary);
    font-weight: 600;
    font-size: 1.1rem;
}

.form-group label i {
    color: var(--accent-color);
}

.input-group {
    position: relative;
}

.form-control {
    width: 100%;
    padding: 1.2rem;
    border: 2px solid rgba(0, 0, 0, 0.1);
    border-radius: var(--border-radius);
    font-size: 1.1rem;
    transition: var(--transition);
    background: white;
    color: var(--text-primary);
}

.form-control:focus {
    border-color: var(--accent-color);
    outline: none;
    box-shadow: 0 0 0 4px rgba(52, 152, 219, 0.1);
    transform: translateY(-2px);
}

.form-control::placeholder {
    color: var(--text-secondary);
    opacity: 0.7;
}

.btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.8rem;
    width: 100%;
    padding: 1.2rem 2rem;
    border: none;
    border-radius: var(--border-radius);
    font-size: 1.1rem;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    position: relative;
    overflow: hidden;
}

.btn-primary {
    background: var(--gradient-primary);
    color: white;
}

.btn-primary::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: var(--transition);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(44, 62, 80, 0.3);
}

.btn-primary:hover::before {
    left: 100%;
}

.auth-links {
    margin-top: 2rem;
    text-align: center;
    padding-top: 1.5rem;
    border-top: 1px solid rgba(0, 0, 0, 0.1);
}

.back-link {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--accent-color);
    text-decoration: none;
    font-weight: 600;
    transition: var(--transition);
    padding: 0.8rem 1.2rem;
    border-radius: var(--border-radius);
}

.back-link:hover {
    color: var(--primary-color);
    background: rgba(52, 152, 219, 0.1);
    transform: translateX(-5px);
}

.alert {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1.2rem 1.5rem;
    border-radius: var(--border-radius);
    margin-bottom: 2rem;
    font-size: 1rem;
    animation: slideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1);
}

@keyframes slideIn {
    from { opacity: 0; transform: translateY(-20px); }
    to { opacity: 1; transform: translateY(0); }
}

.alert i {
    font-size: 1.2rem;
    flex-shrink: 0;
}

.alert-success {
    background-color: rgba(46, 204, 113, 0.1);
    color: var(--success-color);
    border: 1px solid rgba(46, 204, 113, 0.2);
}

.alert-danger {
    background-color: rgba(231, 76, 60, 0.1);
    color: var(--error-color);
    border: 1px solid rgba(231, 76, 60, 0.2);
}

@media (max-width: 768px) {
    .site-nav {
        display: none;
    }

    .header-container {
        justify-content: center;
    }

    .footer-links {
        flex-direction: column;
        gap: 1rem;
    }

    .separator {
        display: none;
    }
}
</style>

<?php require_once '../includes/footer.php'; ?> 
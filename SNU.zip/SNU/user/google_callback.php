<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/google_auth.php';

if (isset($_GET['code'])) {
    $user_info = handleGoogleCallback($_GET['code']);
    
    if ($user_info) {
        try {
            // Check if user exists with this Google ID
            $stmt = $pdo->prepare("SELECT * FROM users WHERE google_id = ?");
            $stmt->execute([$user_info['google_id']]);
            $user = $stmt->fetch();
            
            if (!$user) {
                // Check if user exists with this email
                $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
                $stmt->execute([$user_info['email']]);
                $user = $stmt->fetch();
                
                if ($user) {
                    // Update existing user with Google ID
                    $stmt = $pdo->prepare("UPDATE users SET google_id = ? WHERE id = ?");
                    $stmt->execute([$user_info['google_id'], $user['id']]);
                } else {
                    // Create new user
                    $stmt = $pdo->prepare("INSERT INTO users (username, email, google_id) VALUES (?, ?, ?)");
                    $stmt->execute([$user_info['name'], $user_info['email'], $user_info['google_id']]);
                    $user_id = $pdo->lastInsertId();
                    
                    $user = [
                        'id' => $user_id,
                        'username' => $user_info['name'],
                        'email' => $user_info['email']
                    ];
                }
            }
            
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            
            // Redirect to home page
            header("Location: ../index.php");
            exit();
        } catch(PDOException $e) {
            $_SESSION['error'] = "Authentication failed: " . $e->getMessage();
            header("Location: login.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "Google authentication failed";
        header("Location: login.php");
        exit();
    }
} else {
    header("Location: login.php");
    exit();
}
?> 
<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Get user information
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    $error = "Error fetching user information.";
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $bio = filter_input(INPUT_POST, 'bio', FILTER_SANITIZE_STRING);
    
    try {
        $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, bio = ? WHERE id = ?");
        $stmt->execute([$username, $email, $bio, $_SESSION['user_id']]);
        $success = "Profile updated successfully!";
        
        // Refresh user data
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
    } catch (PDOException $e) {
        $error = "Error updating profile.";
    }
}
?>

<div class="profile-container">
    <div class="profile-sidebar">
        <div class="profile-header">
            <div class="profile-avatar">
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user['username']); ?>&background=2c3e50&color=fff" alt="Profile Avatar">
                <div class="avatar-edit">
                    <i class="fas fa-camera"></i>
                    <span>Change Photo</span>
                </div>
            </div>
            <h1><?php echo htmlspecialchars($user['username']); ?></h1>
            <p class="profile-email">
                <i class="fas fa-envelope"></i>
                <?php echo htmlspecialchars($user['email']); ?>
            </p>
            <div class="profile-stats">
                <div class="stat-item">
                    <span class="stat-value">0</span>
                    <span class="stat-label">Posts</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value">0</span>
                    <span class="stat-label">Comments</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value">0</span>
                    <span class="stat-label">Likes</span>
                </div>
            </div>
        </div>
    </div>

    <div class="profile-content">
        <div class="profile-tabs">
            <button class="tab-btn active" data-tab="profile">Profile</button>
            <button class="tab-btn" data-tab="settings">Settings</button>
            <button class="tab-btn" data-tab="activity">Activity</button>
        </div>

        <div class="tab-content active" id="profile-tab">
            <div class="profile-info">
                <h2>About Me</h2>
                <p class="profile-bio"><?php echo htmlspecialchars($user['bio'] ?? 'No bio yet.'); ?></p>
                
                <div class="info-section">
                    <h3>Account Information</h3>
                    <div class="info-grid">
                        <div class="info-item">
                            <i class="fas fa-user"></i>
                            <span>Username:</span>
                            <strong><?php echo htmlspecialchars($user['username']); ?></strong>
                        </div>
                        <div class="info-item">
                            <i class="fas fa-envelope"></i>
                            <span>Email:</span>
                            <strong><?php echo htmlspecialchars($user['email']); ?></strong>
                        </div>
                        <div class="info-item">
                            <i class="fas fa-calendar"></i>
                            <span>Joined:</span>
                            <strong><?php echo date('F Y', strtotime($user['created_at'])); ?></strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="tab-content" id="settings-tab">
            <form method="POST" class="profile-form">
                <?php if (isset($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="bio">Bio</label>
                    <textarea id="bio" name="bio" rows="4"><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                </div>

                <button type="submit" class="btn-primary">Update Profile</button>
            </form>
        </div>

        <div class="tab-content" id="activity-tab">
            <div class="activity-list">
                <div class="empty-state">
                    <i class="fas fa-history"></i>
                    <p>No activity yet</p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
:root {
    --primary-color: #2c3e50;
    --secondary-color: #e74c3c;
    --accent-color: #3498db;
    --success-color: #2ecc71;
    --error-color: #e74c3c;
    --text-primary: #2c3e50;
    --text-secondary: #7f8c8d;
    --border-radius: 20px;
    --box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
    --transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    --gradient-primary: linear-gradient(135deg, #2c3e50, #3498db);
    --gradient-secondary: linear-gradient(135deg, #3498db, #e74c3c);
    --glass-bg: rgba(255, 255, 255, 0.95);
    --glass-border: rgba(255, 255, 255, 0.2);
    --card-bg: rgba(255, 255, 255, 0.8);
}

body {
    background: linear-gradient(135deg, #f5f7fa, #e5e9f2);
    min-height: 100vh;
}

.profile-container {
    max-width: 1200px;
    margin: 3rem auto;
    padding: 0 1.5rem;
    display: grid;
    grid-template-columns: 300px 1fr;
    gap: 2rem;
}

.profile-sidebar {
    position: sticky;
    top: 2rem;
    height: fit-content;
}

.profile-header {
    background: var(--glass-bg);
    border-radius: var(--border-radius);
    padding: 2.5rem;
    text-align: center;
    box-shadow: var(--box-shadow);
    position: relative;
    overflow: hidden;
    backdrop-filter: blur(10px);
    border: 1px solid var(--glass-border);
}

.profile-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 6px;
    background: var(--gradient-primary);
    animation: gradientFlow 3s ease infinite;
    background-size: 200% 200%;
}

@keyframes gradientFlow {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

.profile-avatar {
    width: 180px;
    height: 180px;
    margin: 0 auto 1.5rem;
    position: relative;
    border-radius: 50%;
    overflow: hidden;
    border: 4px solid white;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
    transition: transform 0.3s ease;
}

.profile-avatar:hover {
    transform: scale(1.05);
}

.profile-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: filter 0.3s ease;
}

.avatar-edit {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    background: rgba(0, 0, 0, 0.7);
    color: white;
    padding: 0.8rem;
    cursor: pointer;
    opacity: 0;
    transform: translateY(100%);
    transition: all 0.3s ease;
}

.profile-avatar:hover .avatar-edit {
    opacity: 1;
    transform: translateY(0);
}

.profile-avatar:hover img {
    filter: brightness(0.9);
}

.profile-header h1 {
    font-size: 2.2rem;
    color: var(--text-primary);
    margin-bottom: 0.5rem;
    font-weight: 700;
    letter-spacing: -0.5px;
}

.profile-email {
    color: var(--text-secondary);
    margin-bottom: 2rem;
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.profile-email i {
    color: var(--accent-color);
}

.profile-stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1rem;
    margin-top: 2rem;
    padding-top: 2rem;
    border-top: 1px solid rgba(0, 0, 0, 0.1);
}

.stat-item {
    text-align: center;
    padding: 1rem;
    border-radius: var(--border-radius);
    background: var(--card-bg);
    transition: var(--transition);
}

.stat-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.stat-value {
    display: block;
    font-size: 2rem;
    font-weight: 700;
    color: var(--primary-color);
    margin-bottom: 0.5rem;
}

.stat-label {
    color: var(--text-secondary);
    font-size: 0.9rem;
    font-weight: 500;
}

.profile-content {
    background: var(--glass-bg);
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    overflow: hidden;
    backdrop-filter: blur(10px);
    border: 1px solid var(--glass-border);
}

.profile-tabs {
    display: flex;
    gap: 0.5rem;
    padding: 1.5rem;
    background: rgba(255, 255, 255, 0.5);
    border-bottom: 1px solid rgba(0, 0, 0, 0.1);
}

.tab-btn {
    padding: 1rem 2rem;
    border: none;
    background: none;
    color: var(--text-secondary);
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    position: relative;
    border-radius: var(--border-radius);
}

.tab-btn:hover {
    color: var(--primary-color);
    background: rgba(255, 255, 255, 0.8);
}

.tab-btn.active {
    color: white;
    background: var(--gradient-primary);
}

.tab-content {
    display: none;
    animation: fadeIn 0.4s ease-out;
    padding: 2rem;
}

.tab-content.active {
    display: block;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

.profile-info {
    background: var(--card-bg);
    border-radius: var(--border-radius);
    padding: 2rem;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
}

.profile-info h2 {
    color: var(--text-primary);
    font-size: 1.8rem;
    margin-bottom: 1.5rem;
    position: relative;
    padding-bottom: 1rem;
}

.profile-info h2::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 60px;
    height: 3px;
    background: var(--gradient-primary);
    border-radius: 3px;
}

.profile-bio {
    color: var(--text-secondary);
    line-height: 1.8;
    font-size: 1.1rem;
    margin-bottom: 2rem;
}

.info-section {
    margin-top: 3rem;
}

.info-section h3 {
    color: var(--text-primary);
    margin-bottom: 1.5rem;
    font-size: 1.4rem;
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1.5rem;
}

.info-item {
    display: flex;
    align-items: center;
    gap: 1.2rem;
    padding: 1.2rem;
    background: var(--glass-bg);
    border-radius: var(--border-radius);
    transition: var(--transition);
    border: 1px solid var(--glass-border);
}

.info-item:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
}

.info-item i {
    color: var(--accent-color);
    font-size: 1.4rem;
    background: rgba(52, 152, 219, 0.1);
    padding: 1rem;
    border-radius: 50%;
}

.info-item span {
    color: var(--text-secondary);
    font-weight: 500;
}

.info-item strong {
    color: var(--text-primary);
    margin-left: auto;
    font-weight: 600;
}

.profile-form {
    background: var(--card-bg);
    border-radius: var(--border-radius);
    padding: 2.5rem;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
}

.form-group {
    margin-bottom: 2rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.8rem;
    color: var(--text-primary);
    font-weight: 600;
    font-size: 1.1rem;
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 1.2rem;
    border: 2px solid rgba(0, 0, 0, 0.1);
    border-radius: var(--border-radius);
    font-size: 1rem;
    transition: var(--transition);
    background: white;
}

.form-group input:focus,
.form-group textarea:focus {
    border-color: var(--accent-color);
    outline: none;
    box-shadow: 0 0 0 4px rgba(52, 152, 219, 0.1);
    transform: translateY(-2px);
}

.btn-primary {
    background: var(--gradient-primary);
    color: white;
    border: none;
    padding: 1.2rem 2.5rem;
    border-radius: var(--border-radius);
    font-size: 1.1rem;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    width: 100%;
    position: relative;
    overflow: hidden;
}

.btn-primary::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: var(--transition);
}

.btn-primary:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(44, 62, 80, 0.3);
}

.btn-primary:hover::before {
    left: 100%;
}

.activity-list {
    background: var(--card-bg);
    border-radius: var(--border-radius);
    padding: 2.5rem;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    min-height: 400px;
}

.empty-state {
    text-align: center;
    color: var(--text-secondary);
    padding: 4rem 2rem;
}

.empty-state i {
    font-size: 4rem;
    margin-bottom: 1.5rem;
    color: var(--accent-color);
    opacity: 0.5;
}

.empty-state p {
    font-size: 1.2rem;
    font-weight: 500;
}

.alert {
    padding: 1.2rem 1.5rem;
    border-radius: var(--border-radius);
    margin-bottom: 2rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    animation: slideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1);
}

@keyframes slideIn {
    from { opacity: 0; transform: translateY(-20px); }
    to { opacity: 1; transform: translateY(0); }
}

.alert::before {
    font-family: 'Font Awesome 5 Free';
    font-weight: 900;
    font-size: 1.2rem;
}

.alert-success {
    background-color: rgba(46, 204, 113, 0.1);
    color: var(--success-color);
    border: 1px solid rgba(46, 204, 113, 0.2);
}

.alert-success::before {
    content: '\f058';
}

.alert-danger {
    background-color: rgba(231, 76, 60, 0.1);
    color: var(--error-color);
    border: 1px solid rgba(231, 76, 60, 0.2);
}

.alert-danger::before {
    content: '\f06a';
}

@media (max-width: 1024px) {
    .profile-container {
        grid-template-columns: 1fr;
    }
    
    .profile-sidebar {
        position: static;
    }
}

@media (max-width: 768px) {
    .profile-container {
        margin: 1.5rem auto;
    }
    
    .profile-header {
        padding: 2rem 1.5rem;
    }
    
    .profile-avatar {
        width: 150px;
        height: 150px;
    }
    
    .profile-stats {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
    
    .profile-tabs {
        overflow-x: auto;
        padding: 1rem;
    }
    
    .tab-btn {
        padding: 0.8rem 1.5rem;
        white-space: nowrap;
    }
    
    .info-grid {
        grid-template-columns: 1fr;
    }
    
    .form-group input,
    .form-group textarea {
        padding: 1rem;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons and contents
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            // Add active class to clicked button and corresponding content
            button.classList.add('active');
            const tabId = button.getAttribute('data-tab');
            document.getElementById(`${tabId}-tab`).classList.add('active');
        });
    });
});
</script>

<?php require_once '../includes/footer.php'; ?> 
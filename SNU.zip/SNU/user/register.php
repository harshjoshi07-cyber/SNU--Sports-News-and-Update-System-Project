<?php
require_once '../includes/config.php';
session_start();

// Debug session information
error_log("Session ID: " . session_id());
error_log("Session status: " . session_status());

// Check if user is already logged in
if (isLoggedIn()) {
    redirect('../index.php');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitizeInput($_POST['username']);
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $full_name = sanitizeInput($_POST['full_name']);
    $csrf_token = $_POST['csrf_token'] ?? '';

    // Debug information
    error_log("Registration attempt - Username: $username, Email: $email, Full Name: $full_name");
    error_log("CSRF Token from form: $csrf_token");
    error_log("CSRF Token in session: " . ($_SESSION['csrf_token'] ?? 'not set'));

    if (!verifyCSRFToken($csrf_token)) {
        $error = 'Invalid request';
        error_log("CSRF verification failed");
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters long';
    } else {
        $conn = getDBConnection();
        if ($conn) {
            try {
                // Check if username or email already exists
                $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
                $stmt->execute([$username, $email]);
                if ($stmt->fetch()) {
                    $error = 'Username or email already exists';
                } else {
                    // Create new user
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$username, $email, $hashed_password, $full_name]);

                    // Create user preferences
                    $user_id = $conn->lastInsertId();
                    $stmt = $conn->prepare("INSERT INTO user_preferences (user_id, preferred_categories, notification_settings) VALUES (?, '[]', '{}')");
                    $stmt->execute([$user_id]);

                    $success = 'Registration successful! You can now login.';
                }
            } catch(PDOException $e) {
                error_log("Registration error: " . $e->getMessage());
                $error = 'An error occurred. Please try again later.';
            }
        } else {
            $error = 'Database connection error';
        }
    }
}

$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - SportsHub</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/auth.css">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h2>Create Account</h2>
                <p>Join SportsHub to stay updated with latest sports news and events</p>
            </div>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <form method="POST" class="auth-form">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" id="full_name" name="full_name" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Sign Up</button>
            </form>

            <div class="auth-divider">
                <span>OR</span>
            </div>

            <div class="social-auth">
                <a href="#" class="btn btn-google">
                    <img src="../assets/images/google-icon.png" alt="Google">
                    Sign up with Google
                </a>
            </div>

            <div class="auth-footer">
                <p>Already have an account? <a href="login.php">Sign In</a></p>
            </div>
        </div>
    </div>
</body>
</html> 
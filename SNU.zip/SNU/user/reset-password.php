<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}

$error = '';
$success = '';
$token = filter_input(INPUT_GET, 'token', FILTER_SANITIZE_STRING);

if (empty($token)) {
    header('Location: login.php');
    exit();
}

// Verify token
try {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE reset_token = ? AND reset_token_expires > NOW()");
    $stmt->execute([$token]);
    $user = $stmt->fetch();

    if (!$user) {
        $error = 'Invalid or expired reset token. Please request a new password reset.';
    }
} catch (PDOException $e) {
    $error = 'An error occurred. Please try again later.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error)) {
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
    $confirm_password = filter_input(INPUT_POST, 'confirm_password', FILTER_SANITIZE_STRING);

    if (empty($password) || empty($confirm_password)) {
        $error = 'Please enter both password fields';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters long';
    } else {
        try {
            // Hash the new password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Update password and clear reset token
            $stmt = $pdo->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_token_expires = NULL WHERE reset_token = ?");
            $stmt->execute([$hashed_password, $token]);

            $success = 'Your password has been reset successfully. You can now login with your new password.';
        } catch (PDOException $e) {
            $error = 'An error occurred while resetting your password. Please try again later.';
        }
    }
}
?>

<div class="auth-container">
    <div class="auth-box">
        <h2>Reset Password</h2>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
            <div class="auth-links">
                <a href="login.php">Go to Login</a>
            </div>
        <?php else: ?>
            <form method="POST" action="reset-password.php?token=<?php echo htmlspecialchars($token); ?>">
                <div class="form-group">
                    <label for="password">New Password</label>
                    <input type="password" id="password" name="password" class="form-control" required minlength="8">
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirm New Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" required minlength="8">
                </div>

                <button type="submit" class="btn btn-primary btn-block">Reset Password</button>
            </form>

            <div class="auth-links">
                <a href="login.php">Back to Login</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
:root {
    --primary-color: #2c3e50;
    --secondary-color: #e74c3c;
    --text-primary: #333;
    --text-secondary: #666;
    --border-radius: 8px;
    --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    --transition: all 0.3s ease;
}

.auth-container {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, rgba(44, 62, 80, 0.05), rgba(231, 76, 60, 0.05));
    padding: 2rem;
    position: relative;
    overflow: hidden;
}

.auth-container::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 5px;
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
}

.auth-box {
    background: white;
    padding: 2.5rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    width: 100%;
    max-width: 450px;
    position: relative;
    z-index: 1;
    transform: translateY(0);
    transition: var(--transition);
}

.auth-box:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
}

.auth-box h2 {
    text-align: center;
    color: var(--primary-color);
    margin-bottom: 2rem;
    font-size: 2rem;
    font-weight: 600;
    position: relative;
    padding-bottom: 1rem;
}

.auth-box h2::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 60px;
    height: 3px;
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
}

.form-group {
    margin-bottom: 1.75rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.75rem;
    color: var(--text-primary);
    font-weight: 500;
    font-size: 1rem;
}

.form-control {
    width: 100%;
    padding: 0.875rem 1rem;
    border: 2px solid #e0e0e0;
    border-radius: var(--border-radius);
    font-size: 1rem;
    transition: var(--transition);
    background-color: #f8f9fa;
}

.form-control:focus {
    border-color: var(--primary-color);
    background-color: white;
    outline: none;
    box-shadow: 0 0 0 3px rgba(44, 62, 80, 0.1);
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: white;
    border: none;
    padding: 0.875rem 1.5rem;
    border-radius: var(--border-radius);
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.btn-block {
    width: 100%;
    display: block;
}

.auth-links {
    margin-top: 2rem;
    text-align: center;
    padding-top: 1rem;
    border-top: 1px solid #e0e0e0;
}

.auth-links a {
    color: var(--primary-color);
    text-decoration: none;
    font-weight: 500;
    transition: var(--transition);
    display: inline-block;
    padding: 0.5rem;
}

.auth-links a:hover {
    color: var(--secondary-color);
    transform: translateX(5px);
}

.alert {
    padding: 1rem 1.25rem;
    margin-bottom: 1.5rem;
    border-radius: var(--border-radius);
    font-size: 0.95rem;
    position: relative;
    padding-left: 2.5rem;
}

.alert::before {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    font-family: 'Font Awesome 5 Free';
    font-weight: 900;
}

.alert-danger {
    background-color: #fff5f5;
    color: #dc3545;
    border: 1px solid #ffc9c9;
}

.alert-danger::before {
    content: '\f06a';
}

.alert-success {
    background-color: #f0fff4;
    color: #28a745;
    border: 1px solid #c3e6cb;
}

.alert-success::before {
    content: '\f058';
}

@media (max-width: 576px) {
    .auth-container {
        padding: 1rem;
    }
    
    .auth-box {
        padding: 2rem 1.5rem;
    }
    
    .auth-box h2 {
        font-size: 1.75rem;
    }
}
</style>

<?php require_once '../includes/footer.php'; ?> 
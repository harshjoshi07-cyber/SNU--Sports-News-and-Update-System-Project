<?php
require_once '../includes/config.php';
session_start();

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!verifyCSRFToken($csrf_token)) {
        $error = 'Invalid request';
    } else {
        try {
            $conn = getDBConnection();
            if (!$conn) {
                throw new Exception('Database connection failed');
            }

            // Get and validate input
            $preferred_categories = isset($_POST['preferred_categories']) ? $_POST['preferred_categories'] : [];
            $notify_events = isset($_POST['notify_events']) ? 1 : 0;
            $notify_news = isset($_POST['notify_news']) ? 1 : 0;

            // Validate categories
            if (!empty($preferred_categories)) {
                $stmt = $conn->prepare("SELECT COUNT(*) FROM sports_categories WHERE id IN (" . str_repeat('?,', count($preferred_categories) - 1) . "?)");
                $stmt->execute($preferred_categories);
                if ($stmt->fetchColumn() !== count($preferred_categories)) {
                    throw new Exception('Invalid category selection');
                }
            }

            // Prepare notification settings
            $notification_settings = json_encode([
                'events' => $notify_events,
                'news' => $notify_news
            ]);

            // Update preferences
            $stmt = $conn->prepare("UPDATE user_preferences SET preferred_categories = ?, notification_settings = ? WHERE user_id = ?");
            $stmt->execute([json_encode($preferred_categories), $notification_settings, $user_id]);

            $success = 'Preferences updated successfully';

        } catch (Exception $e) {
            error_log("Preferences update error: " . $e->getMessage());
            $error = $e->getMessage();
        }
    }
}

// Redirect back to dashboard with status message
$_SESSION['preferences_update_status'] = [
    'success' => $success,
    'error' => $error
];

redirect('dashboard.php');
?> 
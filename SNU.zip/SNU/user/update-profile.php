<?php
require_once '../includes/config.php';
session_start();

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!verifyCSRFToken($csrf_token)) {
        $error = 'Invalid request';
    } else {
        try {
            $conn = getDBConnection();
            if (!$conn) {
                throw new Exception('Database connection failed');
            }

            // Get and validate input
            $full_name = sanitizeInput($_POST['full_name']);
            $email = sanitizeInput($_POST['email']);
            $bio = sanitizeInput($_POST['bio'] ?? '');

            if (empty($full_name) || empty($email)) {
                throw new Exception('Full name and email are required');
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception('Invalid email format');
            }

            // Check if email is already taken by another user
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->execute([$email, $user_id]);
            if ($stmt->fetch()) {
                throw new Exception('Email is already taken');
            }

            // Update user profile
            $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, bio = ? WHERE id = ?");
            $stmt->execute([$full_name, $email, $bio, $user_id]);

            $success = 'Profile updated successfully';

        } catch (Exception $e) {
            error_log("Profile update error: " . $e->getMessage());
            $error = $e->getMessage();
        }
    }
}

// Redirect back to dashboard with status message
$_SESSION['profile_update_status'] = [
    'success' => $success,
    'error' => $error
];

redirect('dashboard.php');
?> 